# Discord Bot - Anleitung

## Installation

1. Entpacke die ZIP-Datei in einen Ordner
2. Erstelle eine `.env` Datei mit folgendem Inhalt:
   ```
   DISCORD_TOKEN=dein_discord_bot_token
   ```
3. Installiere die benötigten Python-Pakete:
   ```
   pip install -r packages_list.txt
   ```
4. Starte den Bot:
   ```
   python main.py
   ```

## Hauptfunktionen

- **Wirtschaftssystem**: Befehle für Währung, Arbeit, Diebstahl, etc.
- **Moderationsbefehle**: Kick, Ban, Mute, Warn, etc.
- **Levelsystem**: XP und Ränge mit Belohnungen
- **Ticketsystem**: Support-Tickets für Benutzer
- **Temporäre Sprachkanäle**: Erstellen von temporären Sprachkanälen
- **Selbstzuweisbare Rollen**: Rollenauswahl durch Benutzer
- **Verifikation**: Einfache und Captcha-Verifikation
- **Willkommensnachrichten**: Personalisierte Nachrichten und Bilder
- **Und vieles mehr**

## Konfiguration

Die meisten Funktionen können über Befehle konfiguriert werden:
- `/setup welcome` - Willkommensnachrichten einrichten
- `/setup tickets` - Ticketsystem einrichten 
- `/setup verification` - Verifikationssystem einrichten

Viel Spaß mit deinem Discord Bot!

Für detaillierte Informationen siehe `discord_bot_anleitung.md`