# database.py
import sqlite3
import datetime
import os
import sys
from typing import Optional, Tuple, List, Dict

# --- Konstante ---
DB_FILE = 'casino.db'

# --- Kernfunktionen ---

def get_db_connection() -> sqlite3.Connection:
    """Stellt eine Datenbankverbindung her und gibt sie zurück.
       Setzt row_factory, um Ergebnisse als Dictionary-ähnliche Objekte zu erhalten."""
    try:
        conn = sqlite3.connect(DB_FILE, timeout=10) # Timeout hinzufügen
        conn.row_factory = sqlite3.Row # Wichtig für Zugriff über Spaltennamen
        conn.execute("PRAGMA foreign_keys = ON") # Fremdschlüssel aktivieren (wichtig!)
        return conn
    except sqlite3.Error as e:
        print(f"[FATAL DB ERROR] Konnte keine Verbindung zur Datenbank '{DB_FILE}' herstellen: {e}", file=sys.stderr)
        traceback.print_exc()
        sys.exit("Database connection failed. Exiting.")


def setup_database():
    """Erstellt alle notwendigen Tabellen in der Datenbank, falls sie nicht existieren."""
    print("📦 Initialisiere Datenbank-Setup...")
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Tabelle für Benutzerguthaben (Wallet)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS economy (
                user_id INTEGER PRIMARY KEY,
                balance INTEGER DEFAULT 0 NOT NULL CHECK(balance >= 0)
            )
        ''')
        print("  -> Tabelle 'economy' geprüft/erstellt.")

        # Tabelle für Bankkonten
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bank (
                user_id INTEGER PRIMARY KEY,
                bank_balance INTEGER DEFAULT 0 NOT NULL CHECK(bank_balance >= 0),
                FOREIGN KEY (user_id) REFERENCES economy(user_id) ON DELETE CASCADE
            )
        ''')
        print("  -> Tabelle 'bank' geprüft/erstellt.")

        # Tabelle für Kredite (Loans)
        cursor.execute('''
             CREATE TABLE IF NOT EXISTS loans (
                 user_id INTEGER PRIMARY KEY,
                 loan_amount INTEGER DEFAULT 0 NOT NULL CHECK(loan_amount >= 0),
                 due_date TEXT, -- ISO Format Timestamp oder NULL
                 FOREIGN KEY (user_id) REFERENCES economy(user_id) ON DELETE CASCADE
             )
         ''')
        print("  -> Tabelle 'loans' geprüft/erstellt.")

        # Tabelle für Shop-Artikel
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS shop_items (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL COLLATE NOCASE, -- UNIQUE und Case-Insensitive
                description TEXT,
                price INTEGER NOT NULL CHECK(price >= 0),
                type TEXT NOT NULL CHECK(type IN ('role', 'boost', 'cosmetic', 'other')), -- Item-Typen
                role_id INTEGER UNIQUE,    -- Role ID sollte UNIQUE sein, wenn type='role'
                usage_limit INTEGER DEFAULT NULL -- Optional, z.B. für Boosts (NULL = unendlich)
            )
        ''')
        print("  -> Tabelle 'shop_items' geprüft/erstellt.")

        # Tabelle für Benutzerinventare
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_inventory (
                inventory_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                item_id INTEGER NOT NULL,
                quantity INTEGER DEFAULT 1 NOT NULL CHECK(quantity > 0),
                purchase_date TEXT NOT NULL, -- ISO Format Timestamp
                FOREIGN KEY (user_id) REFERENCES economy(user_id) ON DELETE CASCADE,
                FOREIGN KEY (item_id) REFERENCES shop_items(item_id) ON DELETE CASCADE,
                UNIQUE(user_id, item_id) -- Ein User kann ein Item nur einmal im Inventar haben (Menge wird erhöht)
            )
        ''')
        print("  -> Tabelle 'user_inventory' geprüft/erstellt.")

        # Tabelle für VIP-Status
        cursor.execute('''
             CREATE TABLE IF NOT EXISTS vip_status (
                 user_id INTEGER PRIMARY KEY,
                 is_vip BOOLEAN DEFAULT 0 NOT NULL,
                 expiry_date TEXT, -- ISO Format Timestamp, NULL für permanent
                 FOREIGN KEY (user_id) REFERENCES economy(user_id) ON DELETE CASCADE
             )
         ''')
        print("  -> Tabelle 'vip_status' geprüft/erstellt.")

        # Tabelle für Befehls-Cooldowns
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cooldowns (
                user_id INTEGER NOT NULL,
                command TEXT NOT NULL COLLATE NOCASE,
                last_used TEXT NOT NULL, -- ISO Format Timestamp
                PRIMARY KEY (user_id, command)
            )
        ''')
        print("  -> Tabelle 'cooldowns' geprüft/erstellt.")

        # Tabelle für KI-aktivierte Kanäle
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS funki_channels (
                guild_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                PRIMARY KEY (guild_id, channel_id)
            )
        ''')
        print("  -> Tabelle 'funki_channels' geprüft/erstellt.")

        # Tabelle für Benutzerverifizierung
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS verification (
                user_id INTEGER PRIMARY KEY,
                verified BOOLEAN DEFAULT 0 NOT NULL
            )
        ''')
        print("  -> Tabelle 'verification' geprüft/erstellt.")

        # Tabelle für das Zählspiel (Counting)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS counting (
                guild_id INTEGER PRIMARY KEY,
                channel_id INTEGER NOT NULL UNIQUE, -- Ein Zählkanal pro Server
                last_number INTEGER DEFAULT 0 NOT NULL,
                last_user_id INTEGER DEFAULT 0 NOT NULL
            )
        ''')
        print("  -> Tabelle 'counting' geprüft/erstellt.")

        conn.commit()
        print("✅ Database setup complete.")
    except sqlite3.Error as e:
        print(f"[FATAL DB ERROR] Fehler während setup_database: {e}", file=sys.stderr)
        conn.rollback()
        traceback.print_exc()
        sys.exit("Database setup failed. Exiting.")
    finally:
        conn.close()

# --- Hilfsfunktion ---
def _ensure_user_economy_exists(cursor: sqlite3.Cursor, user_id: int):
    """Stellt sicher, dass ein Benutzer einen Eintrag in der economy Tabelle hat."""
    cursor.execute("INSERT OR IGNORE INTO economy (user_id, balance) VALUES (?, 0)", (user_id,))

# --- Economy Funktionen ---
# ... (Rest der DB Funktionen wie in der vorherigen Antwort) ...
# --- Economy Funktionen ---

def get_coins(user_id: int) -> int:
    """Holt das aktuelle Guthaben (Wallet) eines Benutzers."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        _ensure_user_economy_exists(cursor, user_id) # Sicherstellen, dass User existiert
        cursor.execute("SELECT balance FROM economy WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result['balance'] if result else 0
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei get_coins für User {user_id}: {e}")
        return 0 # Fallback
    finally:
        conn.close()


def update_coins(user_id: int, amount: int) -> Optional[int]:
    """Aktualisiert das Guthaben (Wallet) eines Benutzers um den gegebenen Betrag (kann negativ sein).
       Gibt den neuen Kontostand zurück oder None bei Fehler. Verhindert negativen Kontostand."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        _ensure_user_economy_exists(cursor, user_id)
        cursor.execute("SELECT balance FROM economy WHERE user_id = ?", (user_id,))
        current_balance = cursor.fetchone()['balance']
        
        new_balance = current_balance + amount
        if new_balance < 0:
            # Nicht genug Geld für eine negative Änderung
            conn.rollback()
            return None 
        
        cursor.execute("UPDATE economy SET balance = ? WHERE user_id = ?", (new_balance, user_id))
        conn.commit()
        return new_balance
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei update_coins für User {user_id}, Betrag {amount}: {e}")
        conn.rollback()
        return None # Fehler signalisieren
    finally:
        conn.close()

def transfer_coins(sender_id: int, receiver_id: int, amount: int) -> bool:
    """Überweist Coins vom Sender zum Empfänger. Gibt True bei Erfolg zurück."""
    if amount <= 0: return False
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")

        # Sender prüfen und Coins abziehen
        _ensure_user_economy_exists(cursor, sender_id)
        cursor.execute("SELECT balance FROM economy WHERE user_id = ?", (sender_id,))
        sender_row = cursor.fetchone()
        if not sender_row or sender_row['balance'] < amount:
            conn.rollback()
            return False # Nicht genug Geld

        new_sender_balance = sender_row['balance'] - amount
        cursor.execute("UPDATE economy SET balance = ? WHERE user_id = ?", (new_sender_balance, sender_id))

        # Empfänger sicherstellen und Coins hinzufügen
        _ensure_user_economy_exists(cursor, receiver_id)
        cursor.execute("UPDATE economy SET balance = balance + ? WHERE user_id = ?", (amount, receiver_id))

        conn.commit()
        return True

    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei transfer_coins (Sender: {sender_id}, Empfänger: {receiver_id}, Betrag: {amount}): {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def get_top_users(limit: int = 10) -> List[Dict]:
    """Holt die Benutzer mit dem höchsten Guthaben (Wallet)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT user_id, balance FROM economy ORDER BY balance DESC LIMIT ?", (limit,))
        results = cursor.fetchall()
        return [dict(row) for row in results]
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei get_top_users (Limit: {limit}): {e}")
        return []
    finally:
        conn.close()

# --- Bank Funktionen ---
def _ensure_user_bank_exists(cursor: sqlite3.Cursor, user_id: int):
    """Stellt sicher, dass ein Benutzer einen Eintrag in der bank Tabelle hat."""
    _ensure_user_economy_exists(cursor, user_id)
    cursor.execute("INSERT OR IGNORE INTO bank (user_id, bank_balance) VALUES (?, 0)", (user_id,))

def get_bank_balance(user_id: int) -> int:
    """Holt den Kontostand auf der Bank eines Benutzers."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        _ensure_user_bank_exists(cursor, user_id)
        cursor.execute("SELECT bank_balance FROM bank WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result['bank_balance'] if result else 0
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei get_bank_balance für User {user_id}: {e}")
        return 0
    finally:
        conn.close()

def update_bank_balance(user_id: int, amount: int) -> Optional[int]:
    """Aktualisiert das Bankguthaben um den Betrag. Gibt neuen Bankstand zurück oder None bei Fehler."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        _ensure_user_bank_exists(cursor, user_id)
        cursor.execute("SELECT bank_balance FROM bank WHERE user_id = ?", (user_id,))
        current_balance = cursor.fetchone()['bank_balance']
        new_balance = current_balance + amount
        if new_balance < 0:
            conn.rollback()
            return None 
        cursor.execute("UPDATE bank SET bank_balance = ? WHERE user_id = ?", (new_balance, user_id,))
        conn.commit()
        return new_balance
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei update_bank_balance für User {user_id}, Betrag {amount}: {e}")
        conn.rollback()
        return None
    finally:
        conn.close()


# --- Loan Funktionen (Basis) ---
def get_loan(user_id: int) -> Optional[Dict]:
    """Holt Informationen zu einem aktiven Kredit."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT loan_amount, due_date FROM loans WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return dict(result) if result else None
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei get_loan für User {user_id}: {e}")
        return None
    finally:
        conn.close()

def create_loan(user_id: int, amount: int, due_date: Optional[str] = None) -> bool:
    """Erstellt einen neuen Kredit für den Benutzer."""
    if amount <= 0: return False
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        _ensure_user_economy_exists(cursor, user_id) 
        # Prüfen ob schon ein Kredit existiert
        cursor.execute("SELECT 1 FROM loans WHERE user_id = ?", (user_id,))
        if cursor.fetchone():
            conn.rollback() # User hat bereits einen Kredit
            return False 
        cursor.execute("INSERT INTO loans (user_id, loan_amount, due_date) VALUES (?, ?, ?)",
                       (user_id, amount, due_date))
        conn.commit()
        return True
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei create_loan für User {user_id}, Betrag {amount}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def update_loan(user_id: int, paid_amount: int) -> Optional[int]:
    """Reduziert den Kreditbetrag um den gezahlten Betrag. Gibt den Restbetrag zurück oder None wenn kein Kredit."""
    if paid_amount <= 0: return None
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        cursor.execute("SELECT loan_amount FROM loans WHERE user_id = ?", (user_id,))
        loan_row = cursor.fetchone()
        if not loan_row:
            conn.rollback()
            return None # Kein Kredit zum zurückzahlen

        remaining = loan_row['loan_amount'] - paid_amount
        if remaining <= 0:
            cursor.execute("DELETE FROM loans WHERE user_id = ?", (user_id,))
            remaining = 0
        else:
            cursor.execute("UPDATE loans SET loan_amount = ? WHERE user_id = ?", (remaining, user_id))
        conn.commit()
        return remaining
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei update_loan für User {user_id}, Betrag {paid_amount}: {e}")
        conn.rollback()
        return None # Fehler signalisieren
    finally:
        conn.close()

# --- Shop & Inventory Funktionen ---
def get_shop_items() -> List[Dict]:
    """Holt alle Artikel aus dem Shop, sortiert nach Preis."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT item_id, name, description, price, type, role_id FROM shop_items ORDER BY price ASC")
        items = cursor.fetchall()
        return [dict(row) for row in items]
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei get_shop_items: {e}")
        return []
    finally:
        conn.close()

def get_shop_item_by_id(item_id: int) -> Optional[Dict]:
     """Holt einen bestimmten Artikel anhand seiner ID."""
     conn = get_db_connection()
     cursor = conn.cursor()
     try:
         cursor.execute("SELECT * FROM shop_items WHERE item_id = ?", (item_id,))
         item = cursor.fetchone()
         return dict(item) if item else None
     except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei get_shop_item_by_id (ID: {item_id}): {e}")
         return None
     finally:
        conn.close()

def get_shop_item_by_name(name: str) -> Optional[Dict]:
    """Holt einen bestimmten Artikel anhand seines Namens (Groß/Kleinschreibung egal)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Nutzt COLLATE NOCASE aus der Tabellendefinition
        cursor.execute("SELECT * FROM shop_items WHERE name = ?", (name,)) 
        item = cursor.fetchone()
        return dict(item) if item else None
    except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei get_shop_item_by_name (Name: {name}): {e}")
         return None
    finally:
        conn.close()

def get_user_inventory(user_id: int) -> List[Dict]:
    """Holt das Inventar eines Benutzers (verknüpft mit Shop-Item-Details)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT inv.quantity, si.item_id, si.name, si.description, si.type, si.role_id
            FROM user_inventory inv
            JOIN shop_items si ON inv.item_id = si.item_id
            WHERE inv.user_id = ?
            ORDER BY si.name ASC
        """, (user_id,))
        inventory = cursor.fetchall()
        return [dict(row) for row in inventory]
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei get_user_inventory für User {user_id}: {e}")
        return []
    finally:
        conn.close()

def add_item_to_inventory(user_id: int, item_id: int, quantity: int = 1) -> bool:
    """Fügt ein Item zum Inventar hinzu oder erhöht die Menge. Gibt True bei Erfolg zurück."""
    if quantity <= 0: return False
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        _ensure_user_economy_exists(cursor, user_id) 
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        # UNIQUE Constraint (user_id, item_id) in Tabelle nutzen
        cursor.execute("""
            INSERT INTO user_inventory (user_id, item_id, quantity, purchase_date)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id, item_id) DO UPDATE SET quantity = quantity + excluded.quantity
        """, (user_id, item_id, quantity, now))
        conn.commit()
        return True
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei add_item_to_inventory für User {user_id}, Item {item_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def remove_item_from_inventory(user_id: int, item_id: int, quantity: int = 1) -> bool:
    """Entfernt eine bestimmte Menge eines Items aus dem Inventar. Gibt True bei Erfolg zurück."""
    if quantity <= 0: return False
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        cursor.execute("SELECT quantity FROM user_inventory WHERE user_id = ? AND item_id = ?", (user_id, item_id))
        item_row = cursor.fetchone()

        if not item_row or item_row['quantity'] < quantity:
            conn.rollback()
            return False # Nicht im Inventar oder nicht genug Menge

        if item_row['quantity'] == quantity:
            cursor.execute("DELETE FROM user_inventory WHERE user_id = ? AND item_id = ?", (user_id, item_id))
        else:
            cursor.execute("UPDATE user_inventory SET quantity = quantity - ? WHERE user_id = ? AND item_id = ?",
                           (quantity, user_id, item_id))
        conn.commit()
        return True
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei remove_item_from_inventory für User {user_id}, Item {item_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()


# --- VIP Funktionen ---
def set_vip_status(user_id: int, is_vip: bool, expiry_date: Optional[str] = None):
    """Setzt den VIP-Status und das Ablaufdatum für einen Benutzer."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        _ensure_user_economy_exists(cursor, user_id) 
        cursor.execute("INSERT OR REPLACE INTO vip_status (user_id, is_vip, expiry_date) VALUES (?, ?, ?)",
                       (user_id, is_vip, expiry_date))
        conn.commit()
    except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei set_vip_status für User {user_id}: {e}")
         conn.rollback() # Sicherstellen, dass bei Fehler nichts geändert wird
    finally:
        conn.close()

def get_vip_status(user_id: int) -> Tuple[bool, Optional[str]]:
    """Holt den VIP-Status und das Ablaufdatum. Prüft auf Ablauf."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT is_vip, expiry_date FROM vip_status WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()

        if result:
            is_currently_vip = bool(result['is_vip'])
            expiry_iso = result['expiry_date']

            if is_currently_vip and expiry_iso:
                try:
                    expiry_dt = datetime.datetime.fromisoformat(expiry_iso.replace('Z', '+00:00')) 
                    if expiry_dt < datetime.datetime.now(datetime.timezone.utc):
                        # VIP ist abgelaufen, Status in DB aktualisieren (außerhalb dieser Funktion!)
                        # Diese Funktion sollte nur lesen, nicht schreiben, um Seiteneffekte zu vermeiden
                        # print(f"[DB INFO] VIP for user {user_id} expired.") 
                        return False, None # Ist abgelaufen
                except ValueError:
                     print(f"[DB WARN] Invalid expiry date format for user {user_id}: {expiry_iso}")
                     # Behandle ungültiges Datum als nicht abgelaufen

            return is_currently_vip, expiry_iso

        return False, None # Standard: Nicht VIP
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei get_vip_status für User {user_id}: {e}")
        return False, None # Fallback
    finally:
        conn.close()


# --- Cooldown Funktionen ---
def get_last_used(user_id: int, command: str) -> Optional[datetime.datetime]:
    """Holt den letzten Zeitpunkt, an dem ein Benutzer einen Befehl verwendet hat."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT last_used FROM cooldowns WHERE user_id = ? AND command = ?", (user_id, command))
        result = cursor.fetchone()
        if result and result['last_used']:
            try:
                return datetime.datetime.fromisoformat(result['last_used'].replace('Z', '+00:00'))
            except ValueError:
                print(f"[DB WARN] Invalid cooldown timestamp format for user {user_id}, command {command}: {result['last_used']}")
                return None
        return None
    except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei get_last_used für User {user_id}, Cmd {command}: {e}")
         return None
    finally:
        conn.close()

def update_last_used(user_id: int, command: str):
    """Aktualisiert den Zeitpunkt der letzten Nutzung eines Befehls auf jetzt (UTC)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
        cursor.execute("""
            INSERT OR REPLACE INTO cooldowns (user_id, command, last_used)
            VALUES (?, ?, ?)
        """, (user_id, command, now_iso))
        conn.commit()
    except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei update_last_used für User {user_id}, Cmd {command}: {e}")
         conn.rollback()
    finally:
        conn.close()


# --- AI Channel Funktionen ---
def add_ai_channel(guild_id: int, channel_id: int):
    """Fügt einen Kanal zur Liste der KI-Kanäle für einen Server hinzu."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT OR REPLACE INTO funki_channels (guild_id, channel_id) VALUES (?, ?)", (guild_id, channel_id))
        conn.commit()
    except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei add_ai_channel (Guild: {guild_id}, Channel: {channel_id}): {e}")
         conn.rollback()
    finally:
        conn.close()

def remove_ai_channel(guild_id: int, channel_id: int):
     """Entfernt einen Kanal aus der Liste der KI-Kanäle."""
     conn = get_db_connection()
     cursor = conn.cursor()
     try:
         cursor.execute("DELETE FROM funki_channels WHERE guild_id = ? AND channel_id = ?", (guild_id, channel_id))
         conn.commit()
     except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei remove_ai_channel (Guild: {guild_id}, Channel: {channel_id}): {e}")
         conn.rollback()
     finally:
        conn.close()

def is_ai_channel(guild_id: int, channel_id: int) -> bool:
    """Prüft, ob ein Kanal als KI-Kanal für einen Server registriert ist."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT 1 FROM funki_channels WHERE guild_id = ? AND channel_id = ?", (guild_id, channel_id))
        result = cursor.fetchone()
        return result is not None
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei is_ai_channel (Guild: {guild_id}, Channel: {channel_id}): {e}")
        return False
    finally:
        conn.close()


# --- Verification Funktionen ---
def set_verification_status(user_id: int, status: bool):
    """Setzt den Verifizierungsstatus eines Benutzers."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        _ensure_user_economy_exists(cursor, user_id) 
        cursor.execute("INSERT OR REPLACE INTO verification (user_id, verified) VALUES (?, ?)", (user_id, status))
        conn.commit()
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei set_verification_status für User {user_id}: {e}")
        conn.rollback()
    finally:
        conn.close()

def is_verified(user_id: int) -> bool:
    """Prüft, ob ein Benutzer verifiziert ist."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT verified FROM verification WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return bool(result['verified']) if result else False
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei is_verified für User {user_id}: {e}")
        return False # Im Zweifel als nicht verifiziert behandeln
    finally:
        conn.close()

def ensure_verification_entry(user_id: int):
    """Stellt sicher, dass ein Benutzer einen Eintrag in der verification Tabelle hat."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        _ensure_user_economy_exists(cursor, user_id) 
        cursor.execute("INSERT OR IGNORE INTO verification (user_id, verified) VALUES (?, 0)", (user_id,))
        conn.commit()
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei ensure_verification_entry für User {user_id}: {e}")
        conn.rollback()
    finally:
        conn.close()


# --- Counting Funktionen ---
def set_counting_channel(guild_id: int, channel_id: int):
    """Setzt den Zählkanal für einen Server und initialisiert den Zähler."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # UNIQUE constraint auf channel_id wird DB-Fehler auslösen, wenn schon vorhanden
        cursor.execute('''
            INSERT OR REPLACE INTO counting (guild_id, channel_id, last_number, last_user_id)
            VALUES (?, ?, 0, 0)
        ''', (guild_id, channel_id))
        conn.commit()
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei set_counting_channel (Guild: {guild_id}, Channel: {channel_id}): {e}")
        conn.rollback()
    finally:
        conn.close()

def get_counting_info(guild_id: int) -> Optional[Tuple[int, int, int]]:
    """Holt die Zählinformationen für einen Server."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('SELECT channel_id, last_number, last_user_id FROM counting WHERE guild_id = ?', (guild_id,))
        result = cursor.fetchone()
        if result:
            return result['channel_id'], result['last_number'], result['last_user_id']
        return None
    except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei get_counting_info für Guild {guild_id}: {e}")
         return None
    finally:
        conn.close()

def update_counting_info(guild_id: int, last_number: int, last_user_id: int) -> bool:
    """Aktualisiert die letzte Zahl und den letzten Zähler für einen Server."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            UPDATE counting
            SET last_number = ?, last_user_id = ?
            WHERE guild_id = ?
        ''', (last_number, last_user_id, guild_id))
        row_updated = cursor.rowcount > 0
        conn.commit()
        return row_updated 
    except sqlite3.Error as e:
        print(f"[DB ERROR] Fehler bei update_counting_info für Guild {guild_id}: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def reset_counting(guild_id: int):
    """Setzt den Zähler für einen Server zurück auf 0."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            UPDATE counting
            SET last_number = 0, last_user_id = 0
            WHERE guild_id = ?
        ''', (guild_id,))
        conn.commit()
    except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei reset_counting für Guild {guild_id}: {e}")
         conn.rollback()
    finally:
        conn.close()

def stop_counting(guild_id: int):
    """Entfernt den Zählkanal-Eintrag für einen Server."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('DELETE FROM counting WHERE guild_id = ?', (guild_id,))
        conn.commit()
    except sqlite3.Error as e:
         print(f"[DB ERROR] Fehler bei stop_counting für Guild {guild_id}: {e}")
         conn.rollback()
    finally:
        conn.close()


# --- Ende der Datenbankfunktionen ---

# Optional: Führe setup_database einmal aus, wenn das Modul direkt gestartet wird (zum Testen)
if __name__ == "__main__":
    print("Führe Datenbank-Setup aus (Testlauf)...")
    # Optional: DB vorher löschen für frischen Test
    # if os.path.exists(DB_FILE):
    #     print(f"Lösche bestehende Test-DB '{DB_FILE}'...")
    #     os.remove(DB_FILE)
    setup_database()
    print("Datenbank-Setup Test abgeschlossen.")