# cogs/verification.py
import discord
from discord.ext import commands
from discord.ui import View, Button, button
import database as db
import datetime

# Configuration (ensure these match your desired names)
VERIFIED_ROLE_NAME = "Verifiziert"
WELCOME_DM_TITLE = "👋 Willkommen!" # Shorter Title
WELCOME_DM_DESCRIPTION = (
    "Bitte klicke auf den Button unten, um dich auf dem Server **{guild_name}** "
    "zu verifizieren und vollen Zugriff zu erhalten!"
)
VERIFICATION_SUCCESS_MSG = "✅ Verifizierung erfolgreich! Du hast jetzt Zugriff auf **{guild_name}**."
VERIFICATION_FAIL_MSG = "❌ Verifizierung fehlgeschlagen. Bitte versuche es erneut oder kontaktiere einen Admin auf **{guild_name}**."
ALREADY_VERIFIED_MSG = "☑️ Du bist bereits verifiziert."
MULTI_SERVER_WARN_MSG = "⚠️ Du scheinst auf mehreren Servern mit mir zu sein, wo du dich verifizieren musst. Verifizierung für **{guild_name}** wird durchgeführt."
SERVER_FIND_FAIL_MSG = "❌ Konnte den zugehörigen Server nicht finden. Bist du noch Mitglied?"
# Optional: Add Member role assignment after verification?
MEMBER_ROLE_NAME = "Member" # Set to None or "" if no member role should be assigned
ASSIGN_MEMBER_ROLE = True  # Set to False if you don't want to auto-assign a "Member" role


class VerificationView(View):
    def __init__(self, user_id: int, guild_id_on_send: int = None):
        """
        user_id: The ID of the user this view is intended for.
        guild_id_on_send: Optional guild ID context when DM is sent (Not directly used by persistent retrieval, but good for context)
        """
        super().__init__(timeout=None) # Persistent view
        self.user_id = user_id
        # self.target_guild_id = guild_id_on_send # Cannot reliably use instance variables for persistent views' state

    @button(label="Verifizieren", style=discord.ButtonStyle.green, custom_id="persistent_verification_button", emoji="✅")
    async def verify_button(self, interaction: discord.Interaction, button: Button):
        bot_instance = interaction.client # Get the bot instance from the interaction

        # --- 1. Check User ---
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Dies ist nicht deine Verifizierungsnachricht.", ephemeral=True)
            return

        # --- 2. Prevent Double Verification ---
        if db.is_verified(interaction.user.id):
            button.disabled = True
            button.label = "Bereits Verifiziert"
            await interaction.message.edit(view=self) # Update DM message view
            await interaction.response.send_message(ALREADY_VERIFIED_MSG, ephemeral=True)
            return

        # --- 3. Find the Target Guild (Crucial Fix) ---
        target_guild = None
        potential_guilds = []
        user = interaction.user # The user who clicked

        for guild in bot_instance.guilds:
            # Use get_member to check if the user is in this specific guild
            if guild.get_member(user.id):
                potential_guilds.append(guild)

        if not potential_guilds:
            # User is somehow not in any guilds the bot shares? Or left all relevant ones.
            await interaction.response.send_message(SERVER_FIND_FAIL_MSG, ephemeral=True)
            print(f"[!] Verification Error: User {user.name} (ID: {user.id}) not found in any mutual guilds.")
            return

        if len(potential_guilds) == 1:
            target_guild = potential_guilds[0]
            print(f"[*] Verification for {user.name}: Found single mutual guild: {target_guild.name}")
        else:
            # User is in multiple guilds with the bot.
            # Strategy: Assume the first one found is okay, but warn the user.
            # A more complex strategy could involve checking which guild has the specific role
            # or matching against guild_id stored elsewhere if needed.
            target_guild = potential_guilds[0] # Pick the first one found for simplicity
            print(f"[!] Verification for {user.name}: Found multiple mutual guilds ({len(potential_guilds)}). Using first found: {target_guild.name}")
            # Let the user know which server they are being verified on
            await interaction.response.defer(ephemeral=True, thinking=True) # Defer response first
            await interaction.followup.send(MULTI_SERVER_WARN_MSG.format(guild_name=target_guild.name), ephemeral=True)
            # Now continue with the process... use followup for the final message too

        # --- 4. Get Member Object from Target Guild ---
        member = target_guild.get_member(user.id)
        if not member: # Should theoretically not happen if guild was found via get_member
             if 'interaction.response.is_done()' in locals() and not interaction.response.is_done(): await interaction.response.send_message(SERVER_FIND_FAIL_MSG, ephemeral=True)
             else: await interaction.followup.send(SERVER_FIND_FAIL_MSG, ephemeral=True)
             print(f"[!] Verification Error: Could not get Member object for {user.name} in {target_guild.name} despite finding guild.")
             return

        # --- 5. Find or Create Verified Role ---
        verified_role = discord.utils.get(target_guild.roles, name=VERIFIED_ROLE_NAME)
        if not verified_role:
            try:
                verified_role = await target_guild.create_role(
                    name=VERIFIED_ROLE_NAME,
                    color=discord.Color.green(),
                    reason="Automatische Erstellung der Verifizierungsrolle"
                )
                print(f"[+] Rolle '{VERIFIED_ROLE_NAME}' in Server '{target_guild.name}' erstellt.")
            except discord.Forbidden:
                print(f"[!] FEHLER: Bot hat keine Rechte, die Rolle '{VERIFIED_ROLE_NAME}' in '{target_guild.name}' zu erstellen.")
                err_msg = VERIFICATION_FAIL_MSG.format(guild_name=target_guild.name) + " (Rolle fehlt)"
                if not interaction.response.is_done(): await interaction.response.send_message(err_msg, ephemeral=True)
                else: await interaction.followup.send(err_msg, ephemeral=True)
                return
            except Exception as e:
                print(f"[!] FEHLER beim Erstellen der Rolle: {e}")
                err_msg = VERIFICATION_FAIL_MSG.format(guild_name=target_guild.name) + " (Rollenfehler)"
                if not interaction.response.is_done(): await interaction.response.send_message(err_msg, ephemeral=True)
                else: await interaction.followup.send(err_msg, ephemeral=True)
                return

        # --- 6. Assign Role(s) and Update Database ---
        roles_to_add = [verified_role]
        member_role = None
        if ASSIGN_MEMBER_ROLE and MEMBER_ROLE_NAME:
             member_role = discord.utils.get(target_guild.roles, name=MEMBER_ROLE_NAME)
             if member_role:
                 if member_role not in member.roles: # Avoid adding if already present
                      roles_to_add.append(member_role)
             else:
                 print(f"[!] Hinweis: Member-Rolle '{MEMBER_ROLE_NAME}' nicht gefunden in {target_guild.name}.")


        try:
            await member.add_roles(*roles_to_add, reason="Benutzer verifiziert")
            db.set_verification_status(self.user_id, True)

            # --- 7. Update Button and Send Confirmation ---
            button.disabled = True
            button.label = "Verifiziert"
            await interaction.message.edit(view=self) # Update the original DM message

            success_msg = VERIFICATION_SUCCESS_MSG.format(guild_name=target_guild.name)
            if not interaction.response.is_done(): await interaction.response.send_message(success_msg, ephemeral=True)
            else: await interaction.followup.send(success_msg, ephemeral=True)

            print(f"[+] Benutzer {member.name} (ID: {member.id}) in Server '{target_guild.name}' verifiziert.")
            if member_role and member_role in roles_to_add:
                print(f"  [+] Auch Rolle '{member_role.name}' zugewiesen.")

        except discord.Forbidden:
            print(f"[!] FEHLER: Bot hat keine Rechte, {member.name} Rolle(n) in '{target_guild.name}' zu geben.")
            err_msg = VERIFICATION_FAIL_MSG.format(guild_name=target_guild.name) + " (Rechte fehlen)"
            if not interaction.response.is_done(): await interaction.response.send_message(err_msg, ephemeral=True)
            else: await interaction.followup.send(err_msg, ephemeral=True)
        except Exception as e:
            print(f"[!] Unbekannter Fehler bei Rollenzuweisung für {member.name}: {e}")
            err_msg = VERIFICATION_FAIL_MSG.format(guild_name=target_guild.name)
            if not interaction.response.is_done(): await interaction.response.send_message(err_msg, ephemeral=True)
            else: await interaction.followup.send(err_msg, ephemeral=True)


class Verification(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Try to register the persistent view on cog load.
        # Using on_ready might be slightly more reliable if cog loading order matters
        # relative to the bot being fully ready.
        # self.bot.add_view(VerificationView(user_id=0)) # Removed from here, moved to on_ready

    @commands.Cog.listener()
    async def on_ready(self):
        # This is important: Re-registers persistent views across bot restarts.
        # Check if a view with the specific button custom_id is already registered.
        persistent_button_id = "persistent_verification_button"
        view_exists = any(
            child.custom_id == persistent_button_id
            for view in self.bot.persistent_views
            for child in view.children
            if hasattr(child, 'custom_id')
        )

        if not view_exists:
            # Provide a dummy user_id initially, it's replaced by the context in the callback
            self.bot.add_view(VerificationView(user_id=0))
            print("[+] VerificationView Persistent View registered.")
        else:
            print("[.] VerificationView Persistent View already registered.")


    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.bot:
            return # Ignore bots

        print(f"[>] Mitglied beigetreten: {member.name} (ID: {member.id}) auf Server {member.guild.name}")

        # Ensure user has a DB entry (defaults to verified=False)
        db.ensure_verification_entry(member.id)

        # Check if already verified (e.g., rejoined)
        if db.is_verified(member.id):
             print(f"  [.] Benutzer {member.name} ist bereits als verifiziert markiert.")
             # Optional: Re-assign verified role if they rejoined without it?
             verified_role = discord.utils.get(member.guild.roles, name=VERIFIED_ROLE_NAME)
             if verified_role and verified_role not in member.roles:
                 try:
                     await member.add_roles(verified_role, reason="Re-assign verified role on rejoin")
                     print(f"  [+] Fehlende Rolle '{verified_role.name}' an {member.name} bei Wiederbeitritt vergeben.")
                 except Exception as e:
                     print(f"  [!] Fehler beim erneuten Zuweisen der Verified-Rolle für {member.name}: {e}")
             # Maybe assign Member role too if needed?
             if ASSIGN_MEMBER_ROLE and MEMBER_ROLE_NAME:
                 member_role = discord.utils.get(member.guild.roles, name=MEMBER_ROLE_NAME)
                 if member_role and member_role not in member.roles:
                      try:
                          await member.add_roles(member_role, reason="Assign member role on rejoin")
                          print(f"  [+] Fehlende Rolle '{member_role.name}' an {member.name} bei Wiederbeitritt vergeben.")
                      except Exception as e:
                          print(f"  [!] Fehler beim erneuten Zuweisen der Member-Rolle für {member.name}: {e}")
             return # Don't send DM if already verified

        # Prepare DM Embed
        embed = discord.Embed(
            title=WELCOME_DM_TITLE,
            description=WELCOME_DM_DESCRIPTION.format(guild_name=member.guild.name), # Add guild name context
            color=discord.Color.blue(),
            timestamp=datetime.datetime.now(datetime.timezone.utc)
        )
        embed.set_footer(text=f"Willkommen bei {member.guild.name}!")
        if member.guild.icon:
            embed.set_thumbnail(url=member.guild.icon.url)

        # Send DM with the persistent view
        try:
            # Create a specific instance of the view, passing the user ID is crucial for the check inside the callback
            await member.send(embed=embed, view=VerificationView(member.id, guild_id_on_send=member.guild.id))
            print(f"  [>] Verifizierungs-DM an {member.name} gesendet für Server {member.guild.name}.")
        except discord.Forbidden:
            print(f"  [!] FEHLER: Konnte keine DM an {member.name} senden (DMs möglicherweise deaktiviert).")
            # Optional: Maybe log this in a specific server channel so mods know?
            # log_channel = discord.utils.get(member.guild.text_channels, name="mod-log")
            # if log_channel: await log_channel.send(f"⚠️ Konnte keine Verifizierungs-DM an {member.mention} senden.")
        except Exception as e:
            print(f"  [!] FEHLER beim Senden der Verifizierungs-DM an {member.name}: {e}")

# Setup function remains the same
async def setup(bot: commands.Bot):
    await bot.add_cog(Verification(bot))
    print("[+] Verification Cog loaded.")