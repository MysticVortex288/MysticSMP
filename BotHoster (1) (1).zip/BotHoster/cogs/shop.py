# cogs/shop.py
import discord
from discord.ext import commands
import database as db

class Shop(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="shop")
    async def shop(self, ctx: commands.Context):
        """Zeigt die verfügbaren Items im Shop an."""
        items = db.get_shop_items()
        if not items:
            await ctx.send("Der Shop ist derzeit leer.")
            return

        embed = discord.Embed(
            title="🛍️ Willkommen im Shop!",
            description="Benutze `!buy <item name/id>` um etwas zu kaufen.",
            color=discord.Color.purple()
        )

        for item in items:
            # Format role name if it's a role item
            role_mention = ""
            if item['type'] == 'role' and item['role_id']:
                 role = ctx.guild.get_role(item['role_id'])
                 role_mention = f" ({role.mention})" if role else " (Rolle nicht gefunden!)"

            embed.add_field(
                name=f"🛒 {item['name']} (ID: {item['item_id']})",
                value=f"> {item['description'] or 'Keine Beschreibung.'}\n"
                      f"> **Preis:** {item['price']:,} Coins\n"
                      f"> **Typ:** {item['type'].capitalize()}{role_mention}",
                inline=False
            )
        await ctx.send(embed=embed)

    @commands.command(name="buy")
    async def buy(self, ctx: commands.Context, *, item_identifier: str):
        """Kauft ein Item aus dem Shop (per Name oder ID)."""
        item = None
        try:
            # Try buying by ID first
            item_id = int(item_identifier)
            item = db.get_shop_item_by_id(item_id)
        except ValueError:
            # If not an ID, try buying by name
            item = db.get_shop_item_by_name(item_identifier)

        if not item:
            await ctx.send(f"❌ Item '{item_identifier}' nicht im Shop gefunden.")
            return

        user_id = ctx.author.id
        user_balance = db.get_coins(user_id)

        if user_balance < item['price']:
            await ctx.send(f"❌ Du hast nicht genug Coins, um '{item['name']}' zu kaufen. Du brauchst {item['price']:,}, hast aber nur {user_balance:,}.")
            return

        # Special check for role items: Does user already have it?
        if item['type'] == 'role' and item['role_id']:
            role = ctx.guild.get_role(item['role_id'])
            if role and role in ctx.author.roles:
                await ctx.send(f"☑️ Du besitzt die Rolle '{role.name}' bereits.")
                return
            if not role:
                 await ctx.send(f"❌ Fehler: Die mit diesem Item verbundene Rolle (ID: {item['role_id']}) existiert auf dem Server nicht mehr. Kauf abgebrochen.")
                 return

        # --- Perform Purchase ---
        try:
            # 1. Deduct coins
            db.update_coins(user_id, -item['price'])

            # 2. Add item to inventory OR apply effect
            if item['type'] == 'role' and item['role_id']:
                 role_to_add = ctx.guild.get_role(item['role_id']) # Already checked existence
                 await ctx.author.add_roles(role_to_add, reason=f"Gekauft im Shop von {ctx.author}")
                 # Optional: Add entry to vip_status if it's THE VIP role
                 # if role_to_add.name == "VIP": # Check name or ID
                 #     db.set_vip_status(user_id, True, None) # None for permanent expiry
                 # Optional: Add to inventory as a record? Maybe not needed for roles.
            else:
                # Add non-role items to inventory
                db.add_item_to_inventory(user_id, item['item_id'])

            # 3. Send confirmation
            embed = discord.Embed(
                title="✅ Kauf erfolgreich!",
                description=f"Du hast '{item['name']}' für **{item['price']:,}** Coins gekauft.",
                color=discord.Color.green()
            )
            if item['type'] == 'role':
                 embed.description += f"\nDie Rolle {role_to_add.mention} wurde dir hinzugefügt!"
            else:
                 embed.description += f"\nDas Item wurde deinem Inventar hinzugefügt (`!inventory`)."

            new_balance = db.get_coins(user_id)
            embed.set_footer(text=f"Neues Guthaben: {new_balance:,} Coins")
            await ctx.send(embed=embed)
            print(f"[SHOP] {ctx.author.name} bought item '{item['name']}' (ID: {item['item_id']})")

        except discord.Forbidden:
             await ctx.send("❌ Fehler: Ich habe keine Berechtigung, dir diese Rolle zu geben. Kauf abgebrochen.")
             # Rollback coin deduction if possible/needed
             db.update_coins(user_id, item['price'])
        except Exception as e:
             await ctx.send(f"❌ Ein unerwarteter Fehler ist beim Kauf aufgetreten: {e}. Kauf möglicherweise fehlgeschlagen.")
             # Consider rollback here too
             print(f"[SHOP] Error during purchase by {ctx.author.name} for item {item['item_id']}: {e}")


    @commands.command(name="inventory", aliases=["inv"])
    async def inventory(self, ctx: commands.Context, member: discord.Member = None):
        """Zeigt das Inventar eines Benutzers an."""
        if member is None:
            member = ctx.author

        inventory_items = db.get_user_inventory(member.id)

        embed = discord.Embed(
            title=f"🎒 Inventar von {member.display_name}",
            color=discord.Color.orange()
        )
        embed.set_thumbnail(url=member.display_avatar.url)

        if not inventory_items:
            embed.description = "Dein Inventar ist leer."
        else:
            description = ""
            for item in inventory_items:
                description += f"**{item['name']}** (x{item['quantity']})\n"
                # description += f"> *{item['description']}*\n" # Optional: Add description
            embed.description = description

        await ctx.send(embed=embed)

    @commands.command(name="buyvip")
    async def buyvip(self, ctx: commands.Context):
        """Kauft den VIP Status (Shortcut für !buy VIP)."""
        # Finde das VIP Item im Shop (angenommen es heißt "VIP Status")
        vip_item_name = "VIP Status" # Passe dies an den Namen in deiner DB an
        vip_item = db.get_shop_item_by_name(vip_item_name)

        if not vip_item:
            await ctx.send(f"❌ Das VIP-Item ('{vip_item_name}') ist derzeit nicht im Shop verfügbar.")
            return

        # Leite den Kauf an den normalen !buy Befehl weiter
        # Wir rufen die Funktion direkt auf, anstatt einen neuen Befehl zu simulieren
        buy_command = self.bot.get_command("buy")
        if buy_command:
             # Erstelle einen neuen Kontext oder rufe die Funktion direkt auf, wenn möglich
             # Direkter Aufruf ist einfacher:
             await self.buy(ctx, item_identifier=vip_item_name)
        else:
            await ctx.send("Fehler: Konnte den !buy-Befehl nicht finden.")


async def setup(bot: commands.Bot):
    await bot.add_cog(Shop(bot))
    print("🛍️ Shop Cog loaded.")