# cogs/moderation.py
import discord
from discord.ext import commands
import datetime

class Moderation(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="ban")
    @commands.has_permissions(ban_members=True)
    @commands.guild_only()
    async def ban(self, ctx: commands.Context, member: discord.Member, *, reason: str = "Kein Grund angegeben"):
        """Bannt einen User"""
        if member == ctx.author:
            await ctx.send("Du kannst dich nicht selbst bannen.")
            return
        if member == self.bot.user:
            await ctx.send("Das kann ich nicht tun.")
            return
        # Optional: Check role hierarchy
        if ctx.author.top_role <= member.top_role and ctx.guild.owner != ctx.author:
             await ctx.send("Du kannst niemanden mit einer gleichen oder höheren Rolle bannen.")
             return

        try:
            await member.ban(reason=f"{reason} (Gebannt von {ctx.author})")
            embed = discord.Embed(
                title="🚫 Benutzer gebannt",
                description=f"{member.mention} wurde von {ctx.author.mention} gebannt.",
                color=discord.Color.red()
            )
            embed.add_field(name="Grund", value=reason)
            await ctx.send(embed=embed)
            # TODO: Optional: Log den Ban in einen Log-Kanal
            print(f"[MOD] {ctx.author} banned {member}. Reason: {reason}")
        except discord.Forbidden:
            await ctx.send("❌ Ich habe keine Berechtigung, diesen Benutzer zu bannen.")
        except Exception as e:
            await ctx.send(f"❌ Ein Fehler ist aufgetreten: {e}")

    @commands.command(name="kick")
    @commands.has_permissions(kick_members=True)
    @commands.guild_only()
    async def kick(self, ctx: commands.Context, member: discord.Member, *, reason: str = "Kein Grund angegeben"):
        """Kickt einen User"""
        if member == ctx.author:
            await ctx.send("Du kannst dich nicht selbst kicken.")
            return
        if member == self.bot.user:
            await ctx.send("Das kann ich nicht tun.")
            return
        if ctx.author.top_role <= member.top_role and ctx.guild.owner != ctx.author:
             await ctx.send("Du kannst niemanden mit einer gleichen oder höheren Rolle kicken.")
             return

        try:
            await member.kick(reason=f"{reason} (Gekickt von {ctx.author})")
            embed = discord.Embed(
                title="👢 Benutzer gekickt",
                description=f"{member.mention} wurde von {ctx.author.mention} gekickt.",
                color=discord.Color.orange()
            )
            embed.add_field(name="Grund", value=reason)
            await ctx.send(embed=embed)
            # TODO: Optional: Log den Kick
            print(f"[MOD] {ctx.author} kicked {member}. Reason: {reason}")
        except discord.Forbidden:
            await ctx.send("❌ Ich habe keine Berechtigung, diesen Benutzer zu kicken.")
        except Exception as e:
            await ctx.send(f"❌ Ein Fehler ist aufgetreten: {e}")

    @commands.command(name="timeout", aliases=["mute"])
    @commands.has_permissions(moderate_members=True) # Timeout permission
    @commands.guild_only()
    async def timeout(self, ctx: commands.Context, member: discord.Member, minutes: int, *, reason: str = "Kein Grund angegeben"):
        """Timeout für einen User für eine bestimmte Anzahl Minuten."""
        if member == ctx.author:
            await ctx.send("Du kannst dich nicht selbst timeouten.")
            return
        if member == self.bot.user:
            await ctx.send("Das kann ich nicht tun.")
            return
        if ctx.author.top_role <= member.top_role and ctx.guild.owner != ctx.author:
             await ctx.send("Du kannst niemanden mit einer gleichen oder höheren Rolle timeouten.")
             return

        duration = datetime.timedelta(minutes=minutes)
        if duration.total_seconds() > 2419200: # Max timeout is 28 days
             await ctx.send("Timeout kann maximal 28 Tage (40320 Minuten) dauern.")
             return

        try:
            await member.timeout(duration, reason=f"{reason} (Timeout von {ctx.author})")
            embed = discord.Embed(
                title="⏳ Timeout vergeben",
                description=f"{member.mention} wurde von {ctx.author.mention} für {minutes} Minuten getimeoutet.",
                color=discord.Color.light_grey()
            )
            embed.add_field(name="Grund", value=reason)
            embed.timestamp = discord.utils.utcnow() + duration
            embed.set_footer(text="Timeout endet")
            await ctx.send(embed=embed)
            # TODO: Optional: Log den Timeout
            print(f"[MOD] {ctx.author} timed out {member} for {minutes}m. Reason: {reason}")
        except discord.Forbidden:
            await ctx.send("❌ Ich habe keine Berechtigung, diesen Benutzer zu timeouten.")
        except Exception as e:
            await ctx.send(f"❌ Ein Fehler ist aufgetreten: {e}")

    @commands.command(name="untimeout", aliases=["unmute"])
    @commands.has_permissions(moderate_members=True)
    @commands.guild_only()
    async def untimeout(self, ctx: commands.Context, member: discord.Member, *, reason: str = "Timeout aufgehoben"):
        """Hebt einen Timeout für einen User auf."""
        if member == ctx.author:
            await ctx.send("Du kannst deinen eigenen Timeout nicht aufheben.")
            return
        if ctx.author.top_role <= member.top_role and ctx.guild.owner != ctx.author:
             await ctx.send("Du kannst den Timeout von niemanden mit einer gleichen oder höheren Rolle aufheben.")
             return

        try:
            await member.timeout(None, reason=f"{reason} (Aufgehoben von {ctx.author})") # Pass None or timedelta(0)
            embed = discord.Embed(
                title="✅ Timeout aufgehoben",
                description=f"Der Timeout für {member.mention} wurde von {ctx.author.mention} aufgehoben.",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            # TODO: Optional: Log das Event
            print(f"[MOD] {ctx.author} removed timeout for {member}. Reason: {reason}")
        except discord.Forbidden:
            await ctx.send("❌ Ich habe keine Berechtigung, Timeouts zu verwalten.")
        except Exception as e:
            await ctx.send(f"❌ Ein Fehler ist aufgetreten: {e}")


    @commands.command(name="clear", aliases=["purge"])
    @commands.has_permissions(manage_messages=True)
    @commands.guild_only()
    async def clear(self, ctx: commands.Context, amount: int):
        """Löscht eine bestimmte Anzahl von Nachrichten."""
        if amount <= 0:
            await ctx.send("Bitte gib eine positive Zahl an.")
            return
        if amount > 100: # Discord API Limit for bulk delete is 100
            await ctx.send("Ich kann maximal 100 Nachrichten auf einmal löschen.")
            amount = 100

        try:
            # amount + 1 because it includes the command message itself
            deleted = await ctx.channel.purge(limit=amount + 1)
            await ctx.send(f"✅ {len(deleted) - 1} Nachrichten gelöscht.", delete_after=5)
            print(f"[MOD] {ctx.author} cleared {len(deleted) - 1} messages in #{ctx.channel.name}")
            # TODO: Log deletion in detail if needed
        except discord.Forbidden:
            await ctx.send("❌ Ich habe keine Berechtigung, Nachrichten in diesem Kanal zu löschen.")
        except Exception as e:
            await ctx.send(f"❌ Ein Fehler ist aufgetreten: {e}")


async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
    print("👮 Moderation Cog loaded.")