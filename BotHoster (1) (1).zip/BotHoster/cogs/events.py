# cogs/events.py
import discord
from discord.ext import commands
import database as db
import datetime
import traceback
import sys
import processing_guard # <-- Importiere den neuen Wächter

# --- Konfiguration ---
WELCOME_CHANNEL_NAME = "willkommen"
GOODBYE_CHANNEL_NAME = "aufwiedersehen"
VERIFIED_ROLE_NAME = "Verifiziert"

class Events(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        print("✅ Events Cog Initialized")

    # ... (on_ready, on_member_join, on_member_remove bleiben gleich) ...
    @commands.Cog.listener()
    async def on_ready(self):
        # Diese Nachricht erscheint nur einmal, wenn der Bot *vollständig* bereit ist
        print(f'------')
        print(f'🎉 Bot ist eingeloggt als: {self.bot.user} (ID: {self.bot.user.id})')
        print(f'------')
        try:
            prefix = self.bot.command_prefix
            if callable(prefix):
                 prefix = prefix(self.bot, None)[0] if prefix(self.bot, None) else "!"
            activity_name = f"{prefix}help | Dein Allrounder"
            await self.bot.change_presence(activity=discord.Game(name=activity_name))
        except Exception as e:
            print(f"[WARN] Konnte Bot-Status nicht setzen: {e}")
        print(f"🟢 Bot ist bereit und online in {len(self.bot.guilds)} Servern.")

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.bot: return # Ignoriere Bots
        welcome_channel = discord.utils.get(member.guild.text_channels, name=WELCOME_CHANNEL_NAME)
        if welcome_channel:
            embed = discord.Embed(
                title="🎉 Neuer Zuwachs!",
                description=f"Willkommen auf **{member.guild.name}**, {member.mention}!\n\n"
                           f"Schau bitte in deine Direktnachrichten, um dich zu verifizieren.",
                color=discord.Color.green(), timestamp=datetime.datetime.now(datetime.timezone.utc)
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"Mitglied #{member.guild.member_count}")
            try: await welcome_channel.send(embed=embed)
            except discord.Forbidden: print(f"[WARN] Keine Rechte, Willkommensnachricht in #{WELCOME_CHANNEL_NAME} zu senden (Server: {member.guild.name}).")
            except Exception as e: print(f"[ERROR] Fehler beim Senden der Willkommensnachricht: {e}")
        else: print(f"[INFO] Willkommens-Kanal #{WELCOME_CHANNEL_NAME} nicht gefunden auf Server {member.guild.name}.")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        if member.bot: return # Ignoriere Bots
        print(f"[INFO] Mitglied verlassen: {member.name} (ID: {member.id}) von Server {member.guild.name}")
        goodbye_channel = discord.utils.get(member.guild.text_channels, name=GOODBYE_CHANNEL_NAME)
        if goodbye_channel:
            duration_str = "Unbekannt"
            if member.joined_at:
                 try:
                     now_utc = discord.utils.utcnow()
                     duration = now_utc - member.joined_at
                     days = duration.days
                     hours, remainder = divmod(duration.seconds, 3600)
                     minutes, _ = divmod(remainder, 60)
                     duration_str = f"{days} Tag(e), {hours} Stunde(n), {minutes} Minute(n)"
                 except Exception as e: print(f"[WARN] Fehler bei Berechnung der Mitgliedsdauer für {member.name}: {e}")
            embed = discord.Embed(
                title="😢 Abschied", description=f"{member.display_name} ({member.name}#{member.discriminator}) hat den Server verlassen.",
                color=discord.Color.red(), timestamp=discord.utils.utcnow()
            )
            embed.add_field(name="Zeit auf dem Server", value=duration_str)
            embed.set_thumbnail(url=member.display_avatar.url)
            try: await goodbye_channel.send(embed=embed)
            except discord.Forbidden: print(f"[WARN] Keine Rechte, Abschiedsnachricht in #{GOODBYE_CHANNEL_NAME} zu senden (Server: {member.guild.name}).")
            except Exception as e: print(f"[ERROR] Fehler beim Senden der Abschiedsnachricht: {e}")
        else: print(f"[INFO] Abschieds-Kanal #{GOODBYE_CHANNEL_NAME} nicht gefunden auf Server {member.guild.name}.")

    # DER ENTSCHEIDENDE LISTENER!
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        # 1. Ignoriere Bots
        if message.author.bot:
            return

        # 2. Ignoriere DMs für Standardverarbeitung
        if not message.guild:
            return

        # --- Verifizierungs-Check ---
        verified_role = discord.utils.get(message.guild.roles, name=VERIFIED_ROLE_NAME)
        is_admin = message.author.guild_permissions.administrator
        if verified_role and not is_admin and verified_role not in message.author.roles:
            if not message.content.startswith(self.bot.command_prefix):
                try: await message.delete()
                except (discord.Forbidden, discord.NotFound): pass
                except Exception as e: print(f"[ERROR] Fehler beim Löschen der Nachricht von {message.author}: {e}")
                return # Keine weitere Verarbeitung

        # -----------------------------------------
        # --- NEU: Processing Guard Check ---
        # -----------------------------------------
        # Prüfe, ob diese Nachricht bereits in Verarbeitung ist/war.
        if not processing_guard.should_process(message.id):
            # Wenn der Wächter 'False' zurückgibt, brich hier ab.
            # Das bedeutet, 'on_message' wurde für diese ID schon einmal hier durchlaufen.
            # print(f"DEBUG: Guard prevented re-processing message {message.id}") # Nur zum Debuggen
            return
        # -----------------------------------------
        # --- Ende Processing Guard Check ---
        # -----------------------------------------


        # --- Befehle verarbeiten (NUR HIER!) ---
        # Wird nur erreicht, wenn der Guard 'True' zurückgegeben hat.
        # print(f"DEBUG: Processing commands for message {message.id}") # Nur zum Debuggen
        await self.bot.process_commands(message)


    # ... (on_command_error bleibt gleich) ...
    @commands.Cog.listener()
    async def on_command_error(self, ctx: commands.Context, error):
        # Ignorieren, wenn der Befehl einen lokalen Error-Handler hat
        if hasattr(ctx.command, 'on_error'): return

        error = getattr(error, 'original', error)
        if isinstance(error, (commands.CommandNotFound, commands.CheckFailure)): return

        if isinstance(error, commands.CommandOnCooldown):
            seconds = round(error.retry_after, 1)
            embed = discord.Embed(title="⏰ Cooldown Aktiv", description=f"Warte noch **{seconds}s**.", color=discord.Color.orange())
            await ctx.send(embed=embed, delete_after=min(10, int(seconds) + 1), ephemeral=True)
        elif isinstance(error, commands.MissingPermissions):
            perms = ", ".join(f"`{perm.replace('_', ' ').title()}`" for perm in error.missing_permissions)
            embed = discord.Embed(title="🚫 Fehlende Rechte", description=f"Dir fehlt: {perms}.", color=discord.Color.red())
            await ctx.send(embed=embed, ephemeral=True)
        elif isinstance(error, commands.BotMissingPermissions):
             perms = ", ".join(f"`{perm.replace('_', ' ').title()}`" for perm in error.missing_permissions)
             embed = discord.Embed(title="🤖 Bot-Rechte fehlen", description=f"Ich benötige: {perms}.", color=discord.Color.red())
             try: await ctx.send(embed=embed, ephemeral=True)
             except discord.Forbidden: print(f"[WARN] BotMissingPermissions: Konnte Fehlermeldung in #{ctx.channel.name} nicht senden.")
        elif isinstance(error, commands.NoPrivateMessage):
            embed = discord.Embed(title="🛡️ Nur auf Servern", description=f"`{ctx.command.qualified_name}` geht nur auf einem Server.", color=discord.Color.orange())
            try: await ctx.author.send(embed=embed)
            except discord.Forbidden: await ctx.send(embed=embed)
        elif isinstance(error, (commands.UserInputError, commands.BadArgument, commands.MissingRequiredArgument)):
             help_cmd = f"`{ctx.prefix}help {ctx.command.qualified_name}`" if ctx.command else ""
             embed = discord.Embed(title="🤔 Ungültige Eingabe", description=f"Fehler: *{error}*\n{help_cmd}", color=discord.Color.orange())
             await ctx.send(embed=embed)
        else: # Unerwarteter Fehler
            print(f'--- Unbehandelter Fehler: {ctx.command.qualified_name if ctx.command else "Unknown"} ---', file=sys.stderr)
            traceback.print_exception(type(error), error, error.__traceback__, file=sys.stderr)
            print(f'-----------------------------------------------------', file=sys.stderr)
            embed = discord.Embed(title="❌ Unerwarteter Fehler", description=f"Etwas ist schiefgelaufen.", color=discord.Color.dark_red())
            try: await ctx.send(embed=embed)
            except Exception as send_error: print(f"[ERROR] Konnte generische Fehlermeldung nicht senden: {send_error}", file=sys.stderr)


# Standard Setup-Funktion für den Cog
async def setup(bot: commands.Bot):
    cog_name = Events.__name__
    if cog_name in bot.cogs:
        print(f"[WARN] Events Cog ('{cog_name}') ist bereits geladen. Überspringe.")
        return
    try:
        await bot.add_cog(Events(bot))
        print(f"[+] {cog_name} Cog geladen.")
    except Exception as e:
        print(f"[FATAL] Konnte {cog_name} Cog nicht laden: {e}", file=sys.stderr)
        traceback.print_exc()