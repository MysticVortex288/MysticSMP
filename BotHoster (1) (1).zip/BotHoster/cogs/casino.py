# cogs/casino.py
import discord
from discord.ext import commands
import random
import database as db
import asyncio # Für Spiele wie Blackjack/Tower

class Casino(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def check_funds(self, ctx: commands.Context, amount: int) -> bool:
        """Helper to check if user has enough coins."""
        if amount <= 0:
            await ctx.send("Dein Einsatz muss positiv sein.")
            return False
        user_id = ctx.author.id
        balance = db.get_coins(user_id)
        if balance < amount:
            await ctx.send(f"Du hast nicht genug Coins für diesen Einsatz! Dein Guthaben: **{balance:,}**")
            return False
        return True

    @commands.command(name="slots")
    @commands.cooldown(1, 5, commands.BucketType.user) # Cooldown 5s
    async def slots(self, ctx: commands.Context, bet: int):
        """Spielt am Spielautomaten."""
        if not await self.check_funds(ctx, bet):
            ctx.command.reset_cooldown(ctx)
            return

        user_id = ctx.author.id
        db.update_coins(user_id, -bet) # Deduct bet immediately

        # Simple Slot Logic
        emojis = ["🍒", "🍊", "🍋", "🍇", "🔔", "💎", "💰"]
        reels = [random.choice(emojis) for _ in range(3)]
        result_msg = f"| {' | '.join(reels)} |"

        winnings = 0
        win_msg = ""

        # Check winnings (example logic, can be much more complex)
        if reels[0] == reels[1] == reels[2]:
            if reels[0] == "💰": winnings = bet * 10
            elif reels[0] == "💎": winnings = bet * 7
            elif reels[0] == "🔔": winnings = bet * 5
            else: winnings = bet * 3
            win_msg = f"🎉 Jackpot! Du gewinnst **{winnings:,}** Coins!"
        elif reels[0] == reels[1] or reels[1] == reels[2] or reels[0] == reels[2]:
             winnings = bet * 2
             win_msg = f"✨ Kleiner Gewinn! Du gewinnst **{winnings:,}** Coins!"
        else:
             win_msg = "😕 Leider verloren. Versuch es nochmal!"

        if winnings > 0:
            db.update_coins(user_id, winnings)

        embed = discord.Embed(
            title="🎰 Spielautomat 🎰",
            description=f"{ctx.author.mention} setzt **{bet:,}** Coins...\n\n{result_msg}\n\n{win_msg}",
            color=discord.Color.gold() if winnings > 0 else discord.Color.red()
        )
        new_balance = db.get_coins(user_id)
        embed.set_footer(text=f"Neues Guthaben: {new_balance:,} Coins")
        await ctx.send(embed=embed)
        print(f"[CASINO] {ctx.author.name} played slots (bet: {bet}, win: {winnings})")

    @commands.command(name="roulette")
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def roulette(self, ctx: commands.Context, bet_type: str, bet_amount: int):
        """Spielt Roulette (vereinfacht: red/black/green)."""
        # TODO: Implement Roulette logic
        # - Validate bet_type (red, black, green, oder Zahlen?)
        # - Check funds
        # - Deduct bet
        # - Spin the wheel (random.choice oder random.randint)
        # - Determine win/loss based on bet_type and result
        # - Calculate winnings (e.g., red/black 1:1, green 14:1)
        # - Update balance
        # - Send result embed
        await ctx.send(f"🚧 Roulette ist noch nicht implementiert. Dein Einsatz auf '{bet_type}' über {bet_amount} wäre...")

    @commands.command(name="dice")
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def dice(self, ctx: commands.Context, bet: int):
        """Einfaches Würfelspiel gegen den Bot."""
        # TODO: Implement Dice logic
        # - Check funds
        # - Deduct bet
        # - Roll user dice (random.randint(1, 6))
        # - Roll bot dice (random.randint(1, 6))
        # - Compare rolls (user > bot = win, user < bot = lose, user == bot = tie/push?)
        # - Calculate winnings (e.g., 1:1 on win, bet returned on tie)
        # - Update balance
        # - Send result embed showing both rolls
        await ctx.send(f"🚧 Würfelspiel ist noch nicht implementiert. Dein Einsatz: {bet}")


    @commands.command(name="tower")
    async def tower(self, ctx: commands.Context, bet: int):
        """Startet ein Tower-Spiel (TODO)."""
        # This is more complex, requires state management (current level, choices)
        # Might use Views/Buttons for interaction
        await ctx.send(f"🚧 Tower Game ist noch nicht implementiert. Dein Einsatz: {bet}")
        # TODO: Implement Tower game logic
        # - Check funds
        # - Deduct bet (or maybe later?)
        # - Start game loop (e.g., 5 levels)
        # - In each level: present choices (e.g., 3 buttons, one is bad)
        # - Use interaction checks (wait_for) to get user choice
        # - If user picks correctly, proceed to next level (prize increases)
        # - If user picks wrongly, game over, lose bet
        # - If user reaches top or cashes out, award prize
        # - Update balance

    @commands.command(name="blackjack", aliases=["bj"])
    async def blackjack(self, ctx: commands.Context, bet: int):
        """Startet ein Blackjack-Spiel gegen den Bot (TODO)."""
        # Also complex, requires state management (player hand, dealer hand, deck)
        # Uses Views/Buttons for Hit/Stand actions
        await ctx.send(f"🚧 Blackjack ist noch nicht implementiert. Dein Einsatz: {bet}")
        # TODO: Implement Blackjack logic
        # - Check funds
        # - Deduct bet
        # - Create/Shuffle deck
        # - Deal initial hands (player 2 visible, dealer 1 visible, 1 hidden)
        # - Show hands and ask player to Hit or Stand (using View/Buttons)
        # - Handle player actions (Hit: deal card, check bust; Stand: dealer plays)
        # - Dealer plays according to rules (hit until >= 17)
        # - Determine winner based on scores (closest to 21 without bust)
        # - Calculate winnings (1:1, Blackjack pays 3:2?)
        # - Update balance

async def setup(bot: commands.Bot):
    await bot.add_cog(Casino(bot))
    print("🎰 Casino Cog loaded.")