# cogs/bank.py
import discord
from discord.ext import commands
import database as db

class Bank(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="bank", aliases=["kontostand"])
    async def bank(self, ctx: commands.Context, member: discord.Member = None):
        """Zeigt den Kontostand auf der Bank an."""
        if member is None:
            member = ctx.author

        bank_coins = db.get_bank_balance(member.id)
        embed = discord.Embed(
            title="🏦 Bankguthaben",
            description=f"{member.mention} hat **{bank_coins:,}** Coins auf der Bank.",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(name="deposit", aliases=["dep"])
    async def deposit(self, ctx: commands.Context, amount: int):
        """Zahlt Coins vom Guthaben auf das Bankkonto ein."""
        if amount <= 0:
            await ctx.send("Bitte gib einen positiven Betrag an.")
            return

        user_id = ctx.author.id
        wallet_coins = db.get_coins(user_id)

        if wallet_coins < amount:
            await ctx.send(f"Du hast nicht genug Coins im Guthaben. Du hast: **{wallet_coins:,}**")
            return

        # Transaktion: Wallet -> Bank
        wallet_success = db.update_coins(user_id, -amount) # Gibt eigentlich nur new balance zurück
        bank_success = db.update_bank_balance(user_id, amount)

        if bank_success: # update_coins sollte immer klappen, wenn check vorher war
            new_wallet = db.get_coins(user_id)
            new_bank = db.get_bank_balance(user_id)
            embed = discord.Embed(
                title="📥 Einzahlung erfolgreich",
                description=f"Du hast **{amount:,}** Coins auf dein Bankkonto eingezahlt.",
                color=discord.Color.green()
            )
            embed.add_field(name="Neues Guthaben", value=f"{new_wallet:,} Coins", inline=True)
            embed.add_field(name="Neuer Bankstand", value=f"{new_bank:,} Coins", inline=True)
            await ctx.send(embed=embed)
            print(f"[BANK] {ctx.author.name} deposited {amount}")
        else:
            # Sollte nicht passieren, wenn Logik stimmt
             await ctx.send("❌ Ein unerwarteter Fehler bei der Einzahlung ist aufgetreten.")
             # Hier wäre es gut, die Transaktion rückgängig zu machen, falls update_coins schon lief
             # db.update_coins(user_id, amount) # Add back to wallet (careful!)

    @commands.command(name="withdraw", aliases=["with"])
    async def withdraw(self, ctx: commands.Context, amount: int):
        """Hebt Coins vom Bankkonto auf das Guthaben ab."""
        if amount <= 0:
            await ctx.send("Bitte gib einen positiven Betrag an.")
            return

        user_id = ctx.author.id
        bank_coins = db.get_bank_balance(user_id)

        if bank_coins < amount:
            await ctx.send(f"Du hast nicht genug Coins auf der Bank. Du hast: **{bank_coins:,}**")
            return

        # Transaktion: Bank -> Wallet
        bank_success = db.update_bank_balance(user_id, -amount)
        # Wenn Bank erfolgreich, Wallet updaten
        if bank_success:
            db.update_coins(user_id, amount) # Add to wallet
            new_wallet = db.get_coins(user_id)
            new_bank = db.get_bank_balance(user_id)
            embed = discord.Embed(
                title="📤 Abhebung erfolgreich",
                description=f"Du hast **{amount:,}** Coins von deinem Bankkonto abgehoben.",
                color=discord.Color.green()
            )
            embed.add_field(name="Neues Guthaben", value=f"{new_wallet:,} Coins", inline=True)
            embed.add_field(name="Neuer Bankstand", value=f"{new_bank:,} Coins", inline=True)
            await ctx.send(embed=embed)
            print(f"[BANK] {ctx.author.name} withdrew {amount}")
        else:
             await ctx.send("❌ Abhebung fehlgeschlagen. Du kannst nicht mehr abheben, als du besitzt.")


    @commands.command(name="loan")
    async def loan(self, ctx: commands.Context, amount: int):
        """Nimmt einen Kredit auf (TODO)."""
        await ctx.send("🚧 Kreditfunktion ist noch nicht implementiert.")
        # TODO: Implement loan logic
        # - Check if user already has a loan
        # - Check max loan amount (e.g., based on bank balance or total worth)
        # - Calculate interest and due date
        # - Add loan entry to database
        # - Add amount to user's wallet balance

    @commands.command(name="payloan")
    async def payloan(self, ctx: commands.Context, amount: int):
        """Zahlt einen Teil oder den gesamten Kredit zurück (TODO)."""
        await ctx.send("🚧 Kreditzurückzahlung ist noch nicht implementiert.")
        # TODO: Implement payloan logic
        # - Check if user has a loan
        # - Check if user has enough money in wallet
        # - Deduct amount from wallet
        # - Update loan amount in database
        # - If loan fully paid, remove loan entry

async def setup(bot: commands.Bot):
    await bot.add_cog(Bank(bot))
    print("🏦 Bank Cog loaded.")