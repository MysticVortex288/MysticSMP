# cogs/economy.py
import discord
from discord.ext import commands
import random
import datetime
from typing import Optional # Hinzugefügt für type hints

# Import database functions
try:
    import database as db
except ImportError:
    print("ECONOMY COG ERROR: database.py not found!")
    # Verhindern, dass der Cog geladen wird, wenn DB fehlt
    async def setup(bot): print("ECONOMY COG NOT LOADED due to missing database.py")
    raise ImportError("database.py is required for the Economy cog.")


class Economy(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Prüfen ob benötigte DB-Funktionen existieren
        required_db_funcs = ['get_coins', 'update_coins', 'transfer_coins', 'get_top_users', 'get_vip_status']
        missing_funcs = [func for func in required_db_funcs if not hasattr(db, func)]
        if missing_funcs:
            print(f"[ERROR] Economy Cog missing required DB functions: {', '.join(missing_funcs)}")
            # Hier könnte man den Cog deaktivieren oder eine Exception werfen
            self._cog_disabled = True # Markiere Cog als deaktiviert
        else:
            self._cog_disabled = False
            print("✅ Economy Cog Initialized")

    # Cog Check: Verhindert Ausführung von Befehlen, wenn DB-Funktionen fehlen
    async def cog_check(self, ctx: commands.Context) -> bool:
        if hasattr(self, '_cog_disabled') and self._cog_disabled:
            await ctx.send("Economy-System ist aufgrund fehlender Datenbankfunktionen vorübergehend deaktiviert.")
            return False
        return True # Alles ok

    @commands.command(name="balance", aliases=["bal", "konto"])
    async def balance(self, ctx: commands.Context, member: Optional[discord.Member] = None):
        """Zeigt das Guthaben eines Benutzers an (oder dein eigenes)."""
        target_member = member or ctx.author

        coins = db.get_coins(target_member.id)
        embed = discord.Embed(
            title="💰 Guthaben",
            description=f"{target_member.mention} hat **{coins:,}** Coins",
            color=discord.Color.gold()
        )
        embed.set_thumbnail(url=target_member.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(name="daily")
    @commands.cooldown(1, 86400, commands.BucketType.user) # 1 use per 24 hours per user
    async def daily(self, ctx: commands.Context):
        """Holt deine tägliche Belohnung ab. VIPs erhalten mehr."""
        user_id = ctx.author.id
        is_vip, _ = db.get_vip_status(user_id)

        base_min, base_max = 1000, 2000
        vip_bonus_multiplier = 1.5

        if is_vip:
            amount = random.randint(int(base_min * vip_bonus_multiplier), int(base_max * vip_bonus_multiplier))
            vip_msg = " ✨ (VIP Bonus!)"
        else:
            amount = random.randint(base_min, base_max)
            vip_msg = ""

        new_balance = db.update_coins(user_id, amount)
        if new_balance is None: # Fehler beim DB Update
            await ctx.send("Ein Datenbankfehler ist aufgetreten. Bitte versuche es später erneut.")
            ctx.command.reset_cooldown(ctx) # Cooldown zurücksetzen bei Fehler
            return

        embed = discord.Embed(
            title="📅 Tägliche Belohnung",
            description=f"Du hast **{amount:,}** Coins erhalten!{vip_msg}\nKomm morgen wieder!",
            color=discord.Color.green()
        )
        embed.set_footer(text=f"Angefordert von {ctx.author.display_name} | Neues Guthaben: {new_balance:,}", icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)
        print(f"[ECO] {ctx.author.name} claimed daily ({amount} coins, VIP: {is_vip})")


    @commands.command(name="work")
    @commands.cooldown(1, 3600, commands.BucketType.user) # 1 use per 1 hour per user
    async def work(self, ctx: commands.Context):
        """Arbeitet, um Coins zu verdienen. VIPs erhalten mehr."""
        user_id = ctx.author.id
        is_vip, _ = db.get_vip_status(user_id)

        base_min, base_max = 100, 500
        vip_bonus_multiplier = 1.3

        if is_vip:
            amount = random.randint(int(base_min * vip_bonus_multiplier), int(base_max * vip_bonus_multiplier))
            vip_msg = " ✨ (VIP Bonus!)"
        else:
            amount = random.randint(base_min, base_max)
            vip_msg = ""

        new_balance = db.update_coins(user_id, amount)
        if new_balance is None:
             await ctx.send("Ein Datenbankfehler ist aufgetreten. Bitte versuche es später erneut.")
             ctx.command.reset_cooldown(ctx)
             return

        jobs = [
            "🏢 Als Bürokaufmann/-frau", "🚕 Als Taxifahrer/-in", "👨‍🍳 Als Koch/Köchin",
            "🎨 Als Künstler/-in", "🔧 Als Mechaniker/-in", "💻 Als Programmierer/-in",
            "📦 Als Paketbote/-in", "🏪 Als Kassierer/-in", "🌳 Als Gärtner/-in",
            "🎵 Als Straßenmusiker/-in"
        ]
        job = random.choice(jobs)

        embed = discord.Embed(
            title="💼 Arbeit",
            description=f"{job} hast du **{amount:,}** Coins verdient!{vip_msg}",
            color=discord.Color.green()
        )
        embed.set_footer(text=f"Angefordert von {ctx.author.display_name} | Neues Guthaben: {new_balance:,}", icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)
        print(f"[ECO] {ctx.author.name} worked ({amount} coins, VIP: {is_vip})")

    @commands.command(name="beg")
    @commands.cooldown(1, 300, commands.BucketType.user) # 1 use per 5 minutes per user
    async def beg(self, ctx: commands.Context):
        """Bettelt um ein paar Coins. VIPs haben bessere Chancen."""
        user_id = ctx.author.id
        is_vip, _ = db.get_vip_status(user_id)

        fail_chance = 0.30
        if is_vip: fail_chance = 0.15

        if random.random() < fail_chance:
             embed = discord.Embed(title="🙏 Betteln", description="🤷‍♀️ Heute war niemand großzügig. Versuch es später nochmal!", color=discord.Color.orange())
             print(f"[ECO] {ctx.author.name} begged and failed (VIP: {is_vip})")
             new_balance_str = f"{db.get_coins(user_id):,}" # Zeige Balance trotzdem an
        else:
            base_min, base_max = 10, 100
            vip_bonus_multiplier = 1.5

            if is_vip:
                amount = random.randint(int(base_min * vip_bonus_multiplier), int(base_max * vip_bonus_multiplier))
                vip_msg = " (VIP Glück!)"
            else:
                amount = random.randint(base_min, base_max)
                vip_msg = ""

            new_balance = db.update_coins(user_id, amount)
            if new_balance is None:
                await ctx.send("Ein Datenbankfehler ist aufgetreten. Bitte versuche es später erneut.")
                ctx.command.reset_cooldown(ctx)
                return

            responses = [
                "🥺 Ein Passant hat Mitleid", "👵 Eine alte Dame ist großzügig", "🎭 Ein Straßenkünstler teilt",
                "🎪 Ein Zirkusclown ist nett", "🎸 Ein Musiker ist beeindruckt", "🎨 Ein Künstler ist inspiriert",
                "🌟 Ein Fan erkennt dich", "🍀 Dein Glückstag", "💝 Jemand mag dich", "🎁 Ein Geschenk vom Himmel"
            ]
            response = random.choice(responses)
            embed = discord.Embed(title="🙏 Betteln", description=f"{response} und gibt dir **{amount:,}** Coins!{vip_msg}", color=discord.Color.green())
            print(f"[ECO] {ctx.author.name} begged ({amount} coins, VIP: {is_vip})")
            new_balance_str = f"{new_balance:,}"

        embed.set_footer(text=f"Angefordert von {ctx.author.display_name} | Guthaben: {new_balance_str}", icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(name="rob")
    @commands.cooldown(1, 7200, commands.BucketType.user) # 1 use per 2 hours per user
    async def rob(self, ctx: commands.Context, victim: discord.Member):
        """Versucht, einen anderen Benutzer auszurauben (Cooldown: 2h)."""
        author = ctx.author
        if victim.id == author.id:
            await ctx.send(embed=discord.Embed(title="🤔 Moment mal...", description="Du kannst dich nicht selbst ausrauben!", color=discord.Color.red()))
            ctx.command.reset_cooldown(ctx)
            return

        if victim.bot:
            await ctx.send(embed=discord.Embed(title="🤖 Hmmm...", description="Bots haben keine Coins zum Stehlen!", color=discord.Color.red()))
            ctx.command.reset_cooldown(ctx)
            return

        author_coins = db.get_coins(author.id)
        victim_coins = db.get_coins(victim.id)

        min_author_coins = 250
        min_victim_coins = 100

        if author_coins < min_author_coins:
             await ctx.send(embed=discord.Embed(title="❌ Zu arm zum Rauben", description=f"Du brauchst mindestens **{min_author_coins:,}** Coins!", color=discord.Color.red()))
             ctx.command.reset_cooldown(ctx)
             return

        if victim_coins < min_victim_coins:
            await ctx.send(embed=discord.Embed(title="❌ Opfer zu arm", description=f"{victim.mention} hat weniger als {min_victim_coins:,} Coins!", color=discord.Color.red()))
            # Cooldown bleibt aktiv
            return

        # --- Robbery Logic ---
        author_is_vip, _ = db.get_vip_status(author.id)
        success_chance = 0.40
        if author_is_vip: success_chance += 0.15

        if random.random() < success_chance:
            # Erfolg
            steal_percentage, max_steal_flat = 0.15, 2000
            # if author_is_vip: steal_percentage = 0.18 # Optional: VIPs stehlen mehr
            max_stealable = min(int(victim_coins * steal_percentage), max_steal_flat)
            amount = random.randint(max(1, int(max_stealable * 0.5)), max(1, max_stealable))

            # Atomare Transaktion versuchen
            success = db.transfer_coins(victim.id, author.id, -amount) # Trick: Überweise negative Menge vom Opfer an sich selbst = Geld nehmen
            
            if success:
                embed = discord.Embed(title="💰 Erfolgreicher Raub!", description=f"Du klaust {victim.mention} **{amount:,}** Coins!", color=discord.Color.green())
                print(f"[ECO] {author.name} robbed {victim.name} ({amount} coins, VIP: {author_is_vip}, Success)")
            else: # DB Fehler
                 embed = discord.Embed(title="❌ Raub fehlgeschlagen", description="Ein Datenbankfehler ist aufgetreten.", color=discord.Color.dark_red())
                 print(f"[ERROR] DB error during successful rob calculation from {author.name} on {victim.name}")

        else:
            # Fehlgeschlagen
            fine_percentage, max_fine_flat, min_fine_flat = 0.10, 500, 10
            # if author_is_vip: fine_percentage, max_fine_flat = 0.07, 350 # Optional: Kleinere Strafe für VIPs

            fine = random.randint(min_fine_flat, max(min_fine_flat, int(author_coins * fine_percentage)))
            fine = min(fine, max_fine_flat)
            fine = min(fine, author_coins) # Nicht mehr Strafe als man hat

            new_balance = db.update_coins(author.id, -fine)
            if new_balance is not None:
                 embed = discord.Embed(title="🚔 Erwischt!", description=f"Dein Raubversuch bei {victim.mention} scheiterte! Strafe: **{fine:,}** Coins.", color=discord.Color.red())
                 print(f"[ECO] {author.name} failed robbing {victim.name} (paid {fine} fine, VIP: {author_is_vip}, Fail)")
            else: # DB Fehler
                 embed = discord.Embed(title="❌ Raub fehlgeschlagen", description="Ein Datenbankfehler ist beim Abziehen der Strafe aufgetreten.", color=discord.Color.dark_red())
                 print(f"[ERROR] DB error during failed rob fine deduction for {author.name}")


        current_author_coins = db.get_coins(author.id) # Aktuellen Stand holen
        embed.set_footer(text=f"Versuch von {author.display_name} | Dein Guthaben: {current_author_coins:,}", icon_url=author.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(name="pay", aliases=["transfer", "give"])
    @commands.guild_only()
    async def pay(self, ctx: commands.Context, recipient: discord.Member, amount: commands.Range[int, 1, None]): # Menge muss > 0 sein
        """Überweist Coins an einen anderen Benutzer."""
        sender = ctx.author
        if sender.id == recipient.id:
            await ctx.send("Du kannst dir nicht selbst Coins überweisen.")
            return
        # Amount check wird durch commands.Range erledigt
        # if amount <= 0: await ctx.send("Bitte gib einen positiven Betrag an."); return
        if recipient.bot:
            await ctx.send("Bots brauchen keine Coins.")
            return

        sender_balance = db.get_coins(sender.id)
        if sender_balance < amount:
            await ctx.send(f"Du hast nicht genug Coins. Dein Guthaben: **{sender_balance:,}** Coins.")
            return

        success = db.transfer_coins(sender.id, recipient.id, amount)

        if success:
            embed = discord.Embed(title="💸 Überweisung erfolgreich", description=f"Du hast **{amount:,}** Coins an {recipient.mention} gesendet.", color=discord.Color.green())
            new_sender_balance = db.get_coins(sender.id)
            embed.set_footer(text=f"Dein neues Guthaben: {new_sender_balance:,}")
            await ctx.send(embed=embed)
            try:
                dm_embed = discord.Embed(title="💰 Zahlung erhalten", description=f"Du hast **{amount:,}** Coins von {sender.mention} auf Server `{ctx.guild.name}` erhalten.", color=discord.Color.gold())
                await recipient.send(embed=dm_embed)
            except (discord.Forbidden, discord.HTTPException): pass # Ignore DM errors
            print(f"[ECO] {sender.name} paid {amount} to {recipient.name}")
        else:
            await ctx.send(embed=discord.Embed(title="❌ Überweisung fehlgeschlagen", description="Möglicherweise ein Datenbankfehler oder das Zielkonto wurde nicht gefunden.", color=discord.Color.red()))
            print(f"[ERROR] Failed to transfer {amount} from {sender.name} to {recipient.name}")


    @commands.command(name="top", aliases=["leaderboard", "lb"])
    async def top(self, ctx: commands.Context, limit: commands.Range[int, 1, 25] = 10): # Limit 1-25, default 10
        """Zeigt die Rangliste der reichsten Benutzer an (Top 1-25)."""
        # Limit check wird durch commands.Range erledigt
        # if not 1 <= limit <= 25: await ctx.send("Limit muss zwischen 1 und 25 sein."); return

        top_users_data = db.get_top_users(limit)

        if not top_users_data:
            await ctx.send("Noch niemand in der Rangliste.")
            return

        description_lines = []
        rank_emojis = {1: "🥇 ", 2: "🥈 ", 3: "🥉 "}

        for i, record in enumerate(top_users_data, 1):
            user_id = record['user_id']
            balance = record['balance']
            user = self.bot.get_user(user_id) # Versuche Cache zuerst
            name = ""
            if user: name = user.mention
            else:
                 try:
                     user = await self.bot.fetch_user(user_id) # Nur fetchen wenn nötig
                     name = user.mention
                 except discord.NotFound: name = f"Unbekannter User ({user_id})"
                 except Exception as e: name = f"Fehler ({user_id})"; print(f"Error fetching user {user_id} for LB: {e}")

            medal = rank_emojis.get(i, f"{i}. ") # Standard Rangnummer wenn keine Medaille
            description_lines.append(f"{medal}{name}: **{balance:,}** Coins")

        embed = discord.Embed(
            title=f"🏆 Top {len(description_lines)} Reichste Spieler",
            description="\n".join(description_lines),
            color=discord.Color.gold(),
            timestamp=discord.utils.utcnow()
        )
        embed.set_footer(text=f"Server: {ctx.guild.name}" if ctx.guild else "Globale Rangliste")
        await ctx.send(embed=embed)

# Standard Cog Setup Funktion
async def setup(bot: commands.Bot):
    cog_name = Economy.__name__
    if cog_name in bot.cogs:
        print(f"[WARN] Economy Cog ('{cog_name}') ist bereits geladen. Überspringe.")
        return
    try:
        await bot.add_cog(Economy(bot))
        # Die Initialized-Nachricht kommt jetzt aus __init__
    except Exception as e:
        print(f"[FATAL] Konnte {cog_name} Cog nicht laden: {e}", file=sys.stderr)
        traceback.print_exc()