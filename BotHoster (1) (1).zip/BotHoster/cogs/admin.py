# cogs/admin.py
import discord
from discord.ext import commands
from discord.ui import View, Button
import database as db # If needed for other admin commands
from typing import List, Tuple



# --- Role Selection Components ---
class RoleButton(discord.ui.Button):
    def __init__(self, role_name: str, emoji: str, style: discord.ButtonStyle):
        # Try to create a custom_id unique enough for persistent views
        safe_role_name = ''.join(filter(str.isalnum, role_name)) # Remove non-alphanumeric chars
        custom_id = f"persistent_role_{safe_role_name[:50]}" # Limit ID length

        super().__init__(
            label=role_name.replace(emoji,'').strip() if emoji in role_name else role_name,
            emoji=emoji,
            style=style,
            custom_id=custom_id
        )
        self.role_name = role_name

    async def callback(self, interaction: discord.Interaction):
        # Ensure user and guild context
        if not interaction.user or not interaction.guild:
            await interaction.response.send_message("Fehler: Benutzer- oder Serverkontext fehlt.", ephemeral=True)
            return

        member = interaction.guild.get_member(interaction.user.id)
        if not member:
             await interaction.response.send_message("Fehler: Mitglied nicht im Server gefunden.", ephemeral=True)
             return

        # Find the role
        role = discord.utils.find(lambda r: r.name.lower() == self.role_name.lower(), interaction.guild.roles)

        if not role:
            await interaction.response.send_message(f"❌ Fehler: Die Rolle `{self.role_name}` wurde nicht gefunden!", ephemeral=True)
            return

        # Toggle the role
        try:
            if role in member.roles:
                await member.remove_roles(role, reason="Selbstzuweisung entfernt")
                embed = discord.Embed(
                    title="🗑️ Rolle entfernt",
                    description=f"Dir wurde die Rolle {role.mention} entfernt!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                print(f"[-] Rolle '{role.name}' von {member.name} entfernt.")
            else:
                await member.add_roles(role, reason="Selbstzuweisung")
                embed = discord.Embed(
                    title="✅ Rolle hinzugefügt",
                    description=f"Dir wurde die Rolle {role.mention} hinzugefügt!",
                    color=discord.Color.green()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                print(f"[+] Rolle '{role.name}' an {member.name} vergeben.")
        except discord.Forbidden:
            await interaction.response.send_message(f"❌ Fehler: Ich habe keine Berechtigung, die Rolle `{role.name}` zu verwalten.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Ein unbekannter Fehler ist aufgetreten: {e}", ephemeral=True)
            print(f"[!] FEHLER beim Umschalten der Rolle '{role.name}' für {member.name}: {e}")


class RoleView(discord.ui.View):
    # Roles is a list of tuples: (role_name, emoji, style)
    def __init__(self, roles: List[Tuple[str, str, discord.ButtonStyle]]):
        super().__init__(timeout=None) # Persistent view
        # Add buttons dynamically based on the roles passed
        for role_name, emoji, style in roles:
            self.add_item(RoleButton(role_name, emoji, style))

# --- Admin Cog ---
class Admin(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._register_role_views() # Register views on init

    def _register_role_views(self):
        """Helper to register role views needed by !creatorroles."""
        # Define roles here to avoid defining them in the command every time
        # Make sure this structure matches the one in the command
        self.role_categories = {
            "Altersgruppen": [
                ("12+", "👶", discord.ButtonStyle.secondary),
                ("16+", "🧑", discord.ButtonStyle.secondary),
                ("18+", "🧓", discord.ButtonStyle.secondary)
            ],
            "Geschlecht": [
                ("♂️ Männlich", "♂️", discord.ButtonStyle.blurple),
                ("♀️ Weiblich", "♀️", discord.ButtonStyle.danger)
            ],
            "Plattformen": [
                ("🤖 Android", "📱", discord.ButtonStyle.success), # Adjusted emoji/label slightly
                ("🍎 iOS", "📱", discord.ButtonStyle.secondary), # Adjusted style
                ("💻 PC", "🖥️", discord.ButtonStyle.blurple),
                ("🍏 MacOS", "💻", discord.ButtonStyle.secondary) # Adjusted style
            ],
            "Spiele": [
                ("⛏️ Minecraft", "⛏️", discord.ButtonStyle.success),
                ("🔫 Fortnite", "🎮", discord.ButtonStyle.primary), # Adjusted style
                ("🎮 Roblox", "🕹️", discord.ButtonStyle.primary), # Adjusted emoji
                ("🎯 Valorant", "🎯", discord.ButtonStyle.danger)
            ]
        }
        # Create and register a view instance for each category's buttons
        for roles in self.role_categories.values():
             view_exists = any(
                 isinstance(v, RoleView) and all(
                     b.custom_id == RoleButton(r,e,s).custom_id for b,(r,e,s) in zip(v.children, roles)
                 )
                 for v in self.bot.persistent_views
             )
             if not view_exists:
                 self.bot.add_view(RoleView(roles))
                 print(f"[+] RoleView für {len(roles)} Rollen registriert.")


    @commands.command()
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def creatorroles(self, ctx: commands.Context):
        """Erstellt vordefinierte Rollen und zeigt Auswahlmenüs an."""
        await ctx.send("⚙️ Rollen werden erstellt/überprüft und Auswahlmenüs vorbereitet...")

        created_count = 0
        skipped_count = 0

        # Iterate through categories and roles defined in _register_role_views
        for category, roles in self.role_categories.items():
            print(f"  Verarbeite Kategorie: {category}")
            # Ensure roles exist
            for role_name, _, _ in roles:
                # Use case-insensitive find to check if role exists
                existing_role = discord.utils.find(lambda r: r.name.lower() == role_name.lower(), ctx.guild.roles)
                if not existing_role:
                    try:
                        await ctx.guild.create_role(
                            name=role_name,
                            mentionable=False, # Usually false for self-assignable roles
                            reason="Automatisch durch !creatorroles erstellt"
                        )
                        print(f"    [+] Rolle '{role_name}' erstellt.")
                        created_count += 1
                    except discord.Forbidden:
                        await ctx.send(f"❌ FEHLER: Keine Rechte, um Rolle `{role_name}` zu erstellen. Überspringe.")
                        skipped_count += 1
                        # Skip sending the view for this category if role creation failed? Maybe not.
                    except Exception as e:
                         await ctx.send(f"❌ FEHLER beim Erstellen von Rolle `{role_name}`: {e}. Überspringe.")
                         skipped_count += 1
                else:
                    # print(f"    [.] Rolle '{role_name}' existiert bereits.") # Optional info log
                    skipped_count += 1

            # Create and send Embed + View for the category
            embed = discord.Embed(
                title=f"🎭 Wähle deine {category}-Rollen",
                description="Klicke auf einen Button um die entsprechende Rolle zu erhalten oder zu entfernen!",
                color=discord.Color.blue()
            )
            # Simple list of roles in description might be cleaner
            roles_text = "\n".join(f"{emoji} {name}" for name, emoji, _ in roles)
            embed.add_field(name="Verfügbare Rollen", value=roles_text)
            embed.set_footer(text="Änderungen können ein paar Sekunden dauern.")

            # Send Embed with the persistent View (already registered in __init__)
            try:
                await ctx.send(embed=embed, view=RoleView(roles))
            except Exception as e:
                 await ctx.send(f"❌ FEHLER beim Senden des Auswahlmenüs für '{category}': {e}")

        await ctx.send(f"✅ Rollen-Setup abgeschlossen. {created_count} erstellt, {skipped_count} bereits vorhanden oder übersprungen.")


    # Other admin commands like setupwelcome, setupki, etc. can go here
    # Ensure setupwelcome creates the welcome/goodbye channels if not present
    @commands.command()
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def setupwelcome(self, ctx: commands.Context):
        """Richtet Willkommens/Auf Wiedersehen Kanäle ein."""
        await ctx.send("⚙️ Überprüfe/Erstelle Willkommens- und Abschiedskanäle...")
        guild = ctx.guild
        results = []

        # Default Overwrites (Bot needs send/embed, @everyone cannot send)
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(send_messages=False, read_messages=True),
            guild.me: discord.PermissionOverwrite(send_messages=True, embed_links=True, read_messages=True)
        }

        # Welcome Channel
        welcome_ch = discord.utils.get(guild.text_channels, name=WELCOME_CHANNEL_NAME)
        if not welcome_ch:
            try:
                welcome_ch = await guild.create_text_channel(
                    WELCOME_CHANNEL_NAME,
                    overwrites=overwrites,
                    reason="Setup durch !setupwelcome"
                )
                results.append(f"✅ Willkommens-Kanal {welcome_ch.mention} erstellt.")
            except discord.Forbidden:
                 results.append(f"❌ Keine Rechte zum Erstellen von #{WELCOME_CHANNEL_NAME}.")
            except Exception as e:
                 results.append(f"❌ Fehler beim Erstellen von #{WELCOME_CHANNEL_NAME}: {e}")
        else:
            results.append(f"ℹ️ Willkommens-Kanal {welcome_ch.mention} existiert bereits.")
             # You might want to update permissions here if they are wrong
             # await welcome_ch.edit(overwrites=overwrites, reason="Update durch !setupwelcome")

        # Goodbye Channel
        goodbye_ch = discord.utils.get(guild.text_channels, name=GOODBYE_CHANNEL_NAME)
        if not goodbye_ch:
             try:
                 goodbye_ch = await guild.create_text_channel(
                     GOODBYE_CHANNEL_NAME,
                     overwrites=overwrites,
                     reason="Setup durch !setupwelcome"
                 )
                 results.append(f"✅ Auf Wiedersehen-Kanal {goodbye_ch.mention} erstellt.")
             except discord.Forbidden:
                 results.append(f"❌ Keine Rechte zum Erstellen von #{GOODBYE_CHANNEL_NAME}.")
             except Exception as e:
                 results.append(f"❌ Fehler beim Erstellen von #{GOODBYE_CHANNEL_NAME}: {e}")
        else:
             results.append(f"ℹ️ Auf Wiedersehen-Kanal {goodbye_ch.mention} existiert bereits.")
             # Update permissions if desired

        # Final Report
        embed = discord.Embed(
            title="🛠️ Willkommens/Abschieds-System Setup",
            description="\n".join(results),
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    # Add the setupki command as well
    @commands.command()
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def setupki(self, ctx: commands.Context, channel: discord.TextChannel):
        """Richtet einen KI-Kanal ein."""
        try:
            db.add_ai_channel(ctx.guild.id, channel.id)
            await ctx.send(f"✅ KI-System wurde für den Kanal {channel.mention} eingerichtet.")
            # Optional: Send confirmation in the target channel
            await channel.send(embed=discord.Embed(title="🤖 KI Aktiviert", description="Ich werde jetzt auf Nachrichten in diesem Kanal antworten.", color=discord.Color.blue()))
        except Exception as e:
            await ctx.send(f"❌ Fehler beim Einrichten des KI-Kanals: {e}")
            print(f"[!] FEHLER bei !setupki für Kanal {channel.id}: {e}")


async def setup(bot: commands.Bot):
    await bot.add_cog(Admin(bot))
    print("[+] Admin Cog loaded.")