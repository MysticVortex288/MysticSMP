# cogs/help.py
import discord
from discord.ext import commands
import datetime
from typing import Optional, Dict, List, Union
import sys # <--- Fehlenden Import hinzugefügt

# --- Konfiguration für das Aussehen ---
EMBED_COLOR = discord.Color.blue() # Hauptfarbe für Embeds
ERROR_COLOR = discord.Color.red()
WARN_COLOR = discord.Color.orange()
# WICHTIG: Passe diese Liste an! "HelpCog" sollte drin bleiben.
COGS_TO_IGNORE = ["HelpCog", "Events"] # Cogs, die nicht im Hauptmenü erscheinen sollen

# WICHTIG: Passe diese Zuordnung an deine Cog-Klassennamen an!
COG_EMOJIS_AND_NAMES: Dict[str, tuple[str, str]] = {
    # Interner Cog-Klassenname: (Emoji, Angezeigter Name)
    "Admin":        ("🔧", "Admin & Setup"),
    "Economy":      ("💰", "Economy"),
    "Moderation":   ("👮", "Moderation"),
    "Bank":         ("🏦", "Bank"),
    "Casino":       ("🎰", "Casino & Spiele"),
    "Shop":         ("🛍️", "Shop System"),
    "Verification": ("✅", "Verifizierung"), # Kann erwähnt werden, auch ohne Befehle
    # Füge hier weitere Cogs hinzu, z.B.:
    # "Fun":          ("🎉", "Spaß & Unterhaltung"),
}

# Hilfsfunktion zum Erstellen der Befehlssignatur
def get_command_signature(command: commands.Command, prefix: str) -> str:
    """Generiert eine saubere Signatur für einen Befehl, inklusive Eltern."""
    parent = command.full_parent_name
    name_part = f"{parent} {command.name}" if parent else command.name
    return f'{prefix}{name_part} {command.signature}'


class HelpCog(commands.Cog, name="Help"): # Expliziter Name wichtig
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Speichere das Original, falls benötigt (optional)
        self.original_help_command = bot.help_command
        # Entferne die fehlerhafte Zuweisung! Der Bot wurde schon mit help_command=None initialisiert.
        # bot.help_command = self # <<< DIESE ZEILE ENTFERNEN/AUSKOMMENTIEREN
        print("✅ Help Cog Initialized (Using custom !help command)")

    # Hilfsfunktion zum Formatieren der Befehlsliste für eine Kategorie
    def _format_cog_commands(self, cog: commands.Cog, prefix: str) -> str:
        """Formatiert die Befehle eines Cogs für die Anzeige."""
        cog_commands = cog.get_commands()
        if not cog_commands:
            return "*Keine öffentlichen Befehle in dieser Kategorie.*"

        visible_commands = sorted(
            [cmd for cmd in cog_commands if not cmd.hidden and cmd.parent is None],
            key=lambda c: c.name
        )

        if not visible_commands:
             return "*Keine öffentlichen Top-Level-Befehle in dieser Kategorie.*"

        lines = [f"`{prefix}{cmd.name}`" for cmd in visible_commands]
        return ", ".join(lines) if lines else "*Keine öffentlichen Top-Level-Befehle.*"

    # Der Haupt-Hilfebefehl
    @commands.command(name="help", aliases=["hilfe", "commands", "cmd"])
    async def help_command_impl(self, ctx: commands.Context, *, query: Optional[str] = None):
        """Zeigt diese Hilfenachricht oder Details zu einem Befehl/einer Kategorie."""
        prefix = ctx.prefix
        bot = self.bot # Alias für kürzeren Zugriff

        # --- Fall 1: Keine spezifische Anfrage (!help) -> Hauptmenü ---
        if query is None:
            embed = discord.Embed(
                title="🤖 Bot Hilfe & Befehlsübersicht",
                description=f"Hier sind die verfügbaren Befehlskategorien.\n"
                            f"Nutze `{prefix}help <Kategorie/Befehl>` für mehr Details.",
                color=EMBED_COLOR,
                timestamp=discord.utils.utcnow()
            )

            sorted_cogs = sorted(
                [cog for cog in bot.cogs.values() if cog.qualified_name not in COGS_TO_IGNORE and cog.get_commands()],
                key=lambda c: COG_EMOJIS_AND_NAMES.get(c.qualified_name, ("", c.qualified_name))[1]
            )

            for cog in sorted_cogs:
                cog_name = cog.qualified_name
                emoji, display_name = COG_EMOJIS_AND_NAMES.get(cog_name, ("", cog_name))
                commands_str = self._format_cog_commands(cog, prefix)
                if commands_str != "*Keine öffentlichen Befehle in dieser Kategorie.*" and \
                   commands_str != "*Keine öffentlichen Top-Level-Befehle in dieser Kategorie.*":
                     embed.add_field(name=f"{emoji} {display_name}", value=commands_str, inline=False)


            embed.set_footer(text=f"Angefordert von {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
            if bot.user.avatar:
                 embed.set_thumbnail(url=bot.user.avatar.url)

            await ctx.send(embed=embed)
            return

        # --- Fall 2: Spezifische Anfrage (!help <query>) ---
        query_lower = query.lower()

        # 2a: Ist die Anfrage ein bekannter Befehl (oder Alias)?
        found_command = bot.get_command(query_lower)
        if found_command:
            # Behandle Gruppen separat für Sub-Befehle
            if isinstance(found_command, commands.Group):
                 await self.send_group_command_help(ctx, found_command)
            else:
                 await self.send_single_command_help(ctx, found_command)
            return

        # 2b: Ist die Anfrage ein Kategoriename?
        found_cog = None
        found_display_name = ""
        found_emoji = ""
        for cog_name, cog_instance in bot.cogs.items():
            if cog_name in COGS_TO_IGNORE: continue
            emoji, display_name_cfg = COG_EMOJIS_AND_NAMES.get(cog_name, ("", cog_name))
            if query_lower == cog_name.lower() or query_lower == display_name_cfg.lower().replace('&', 'and'):
                found_cog = cog_instance
                found_display_name = display_name_cfg
                found_emoji = emoji
                break

        if found_cog:
            await self.send_category_help(ctx, found_cog, found_display_name, found_emoji)
            return

        # --- Fall 3: Nichts gefunden ---
        embed = discord.Embed(
            title="❓ Nichts gefunden",
            description=f"Konnte keinen Befehl oder keine Kategorie namens `{query}` finden.\n"
                        f"Nutze `{prefix}help` für eine Liste aller Kategorien.",
            color=ERROR_COLOR
        )
        await ctx.send(embed=embed)


    async def send_single_command_help(self, ctx: commands.Context, command: commands.Command):
        """Sendet detaillierte Hilfe für einen einzelnen Befehl."""
        prefix = ctx.prefix
        embed = discord.Embed(
            title=f"🔍 Hilfe für Befehl: `{prefix}{command.qualified_name}`",
            description=command.help or "Keine Beschreibung verfügbar.",
            color=EMBED_COLOR, timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Verwendung", value=f"`{get_command_signature(command, prefix)}`", inline=False)
        if command.aliases:
            embed.add_field(name="Aliase", value=", ".join(f"`{prefix}{a}`" for a in command.aliases), inline=True)
        if command.cog:
             cog_name = command.cog.qualified_name
             emoji, display_name = COG_EMOJIS_AND_NAMES.get(cog_name, ("", cog_name))
             embed.add_field(name="Kategorie", value=f"{emoji} {display_name}", inline=True)
        embed.set_footer(text="< > = Erforderlich, [ ] = Optional")
        await ctx.send(embed=embed)

    async def send_group_command_help(self, ctx: commands.Context, group: commands.Group):
        """Sendet detaillierte Hilfe für eine Befehlsgruppe."""
        prefix = ctx.prefix
        embed = discord.Embed(
            title=f"🔍 Hilfe für Gruppe: `{prefix}{group.qualified_name}`",
            description=group.help or "Keine Beschreibung für diese Gruppe verfügbar.",
            color=EMBED_COLOR, timestamp=discord.utils.utcnow()
        )
        embed.add_field(name="Verwendung (Gruppe)", value=f"`{get_command_signature(group, prefix)}`", inline=False)

        sub_commands = sorted([cmd for cmd in group.commands if not cmd.hidden], key=lambda c: c.name)
        if sub_commands:
            sub_command_list = []
            for cmd in sub_commands:
                sig = get_command_signature(cmd, prefix) # Volle Signatur für Sub-Befehl
                short_doc = cmd.short_doc or "Keine Beschreibung."
                sub_command_list.append(f"**`{sig}`**: {short_doc.strip()}")
            embed.add_field(name="Unterbefehle", value="\n".join(sub_command_list), inline=False)

        if group.aliases:
            embed.add_field(name="Aliase (Gruppe)", value=", ".join(f"`{prefix}{a}`" for a in group.aliases), inline=True)
        if group.cog:
             cog_name = group.cog.qualified_name
             emoji, display_name = COG_EMOJIS_AND_NAMES.get(cog_name, ("", cog_name))
             embed.add_field(name="Kategorie", value=f"{emoji} {display_name}", inline=True)
        embed.set_footer(text="< > = Erforderlich, [ ] = Optional")
        await ctx.send(embed=embed)

    async def send_category_help(self, ctx: commands.Context, cog: commands.Cog, display_name: str, emoji: str):
         """Sendet Hilfe für eine spezifische Kategorie (Cog)."""
         prefix = ctx.prefix
         embed = discord.Embed(
            title=f"{emoji} Kategorie: {display_name}",
            description=cog.description or f"Befehle in der Kategorie `{display_name}`:",
            color=EMBED_COLOR, timestamp=discord.utils.utcnow()
         )
         visible_commands = sorted([cmd for cmd in cog.get_commands() if not cmd.hidden], key=lambda c: c.name)
         if visible_commands:
            for cmd in visible_commands:
                 signature = get_command_signature(cmd, prefix)
                 short_doc = cmd.short_doc or "Keine Beschreibung."
                 embed.add_field(name=f"`{signature}`", value=f"{short_doc.strip()}", inline=False)
         else:
              embed.description = f"Die Kategorie `{display_name}` enthält keine öffentlichen Befehle."
         embed.set_footer(text=f"Nutze {prefix}help <BefehlName> für Details.")
         await ctx.send(embed=embed)


# Standard Setup-Funktion für den Cog
async def setup(bot: commands.Bot):
    cog_name = HelpCog.__name__
    if cog_name in bot.cogs:
        print(f"[WARN] Help Cog ('{cog_name}') ist bereits geladen. Überspringe.")
        return
    try:
        await bot.add_cog(HelpCog(bot))
        # Die Initialized-Nachricht kommt jetzt aus __init__
    except Exception as e:
        print(f"[FATAL] Konnte {cog_name} Cog nicht laden: {e}", file=sys.stderr) # Nutze sys.stderr
        traceback.print_exc()