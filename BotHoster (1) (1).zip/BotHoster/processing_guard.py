# processing_guard.py
import collections
import time
from typing import Deque

# Konfiguration: Wie viele Nachrichten-IDs sollen maximal gespeichert werden?
# Dies verhindert, dass die Liste unendlich wächst.
MAX_RECENT_MESSAGES: int = 500

# Eine Deque (Double-ended Queue) mit fester Länge verwenden.
# Wenn mehr als MAX_RECENT_MESSAGES hinzugefügt werden, wird das älteste Element automatisch entfernt.
# Das ist speichereffizienter als ein Set, das manuell geleert werden müsste.
_processed_message_ids: Deque[int] = collections.deque(maxlen=MAX_RECENT_MESSAGES)

# Ein Zeitstempel, um ggf. zu debuggen, wann die letzte Nachricht verarbeitet wurde (optional)
_last_processed_time: float = 0.0

# WICHTIG: Dies ist ein Workaround! Finde die Ursache für doppelte Verarbeitung!
print("⚠️  WARNUNG: processing_guard.py ist aktiv. Dies ist ein Workaround für doppelte Nachrichten.")
print("      Bitte behebe die eigentliche Ursache (doppelter process_commands Aufruf, Cog doppelt geladen, Bot doppelt gestartet).")


def should_process(message_id: int) -> bool:
    """
    Prüft, ob eine Nachricht mit dieser ID kürzlich verarbeitet wurde.
    Wenn nicht, wird die ID hinzugefügt und True zurückgegeben.
    Wenn ja, wird False zurückgegeben, um eine erneute Verarbeitung zu blockieren.
    """
    global _processed_message_ids
    global _last_processed_time

    current_time = time.monotonic() # Monotonische Uhr für Zeitmessung

    # Prüfen, ob die ID bereits in der Deque ist
    if message_id in _processed_message_ids:
        # Die Nachricht wurde bereits kürzlich als "in Verarbeitung" markiert.
        # Blockiere diesen erneuten Versuch.
        # print(f"DEBUG (Guard): Nachricht {message_id} bereits in Bearbeitung/kürzlich verarbeitet. Blockiert.")
        return False
    else:
        # Nachricht ist neu (oder zumindest nicht mehr in der Deque).
        # Füge die ID zur Deque hinzu (älteste ID fällt ggf. raus).
        _processed_message_ids.append(message_id)
        _last_processed_time = current_time
        # print(f"DEBUG (Guard): Nachricht {message_id} zur Verarbeitung zugelassen und markiert.")
        return True

# Optional: Funktion, um den Status zu überprüfen (zum Debuggen)
def get_guard_status() -> str:
    return f"Guard Status: Tracking last {len(_processed_message_ids)}/{MAX_RECENT_MESSAGES} message IDs. Last processed: {time.monotonic() - _last_processed_time:.2f}s ago."