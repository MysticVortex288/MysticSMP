# bot.py
import discord
from discord.ext import commands
import os
import asyncio
from dotenv import load_dotenv
import traceback
import sys

# --- Lade Umgebungsvariablen ---
load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')

if not TOKEN:
    print("❌ FATAL ERROR: DISCORD_TOKEN environment variable not found.", file=sys.stderr)
    print("   Ensure you have a .env file in the same directory with DISCORD_TOKEN='YOUR_BOT_TOKEN'", file=sys.stderr)
    sys.exit("Bot token not found. Exiting.") # Beendet das Skript

# --- Importiere Datenbank (wird früh gebraucht) ---
try:
    import database as db
except ImportError:
    print("❌ FATAL ERROR: database.py not found or cannot be imported.", file=sys.stderr)
    sys.exit("Database module missing. Exiting.")

# --- Definiere Intents ---
# Minimal benötigte Intents + die für deine Features
intents = discord.Intents.default()
intents.message_content = True # Für Befehle und on_message Checks
intents.members = True         # Für member join/leave, Rollenvergabe, User-Infos
# intents.presences = False   # Normalerweise nicht benötigt

# --- Initialisiere den Bot ---
# WICHTIG: help_command=None, da wir einen eigenen Help-Cog haben
bot = commands.Bot(
    command_prefix="!",
    intents=intents,
    help_command=None, # Sehr wichtig!
    case_insensitive=True
)

# --- Lade Cogs ---
async def load_extensions():
    """Lädt alle Cogs aus dem 'cogs'-Verzeichnis."""
    print("🔄 Loading Cogs...")
    loaded_cogs = 0
    failed_cogs = 0
    cogs_path = './cogs'
    if not os.path.isdir(cogs_path):
        print(f"    ⚠️ Warning: Directory '{cogs_path}' not found. No cogs will be loaded.")
        return

    print(f"--- Files/Dirs in '{cogs_path}': {os.listdir(cogs_path)} ---")
    for filename in os.listdir(cogs_path):
        # Lade nur .py Dateien, ignoriere solche, die mit '_' anfangen
        if filename.endswith('.py') and not filename.startswith('_'):
            extension_name = f'cogs.{filename[:-3]}'
            print(f"  🧐 Checking: {extension_name}")
            try:
                # Nur laden, wenn noch nicht geladen
                if extension_name not in bot.extensions:
                    print(f"    ➕ Attempting to load: {extension_name}")
                    await bot.load_extension(extension_name)
                    # Die "Cog loaded" Nachricht kommt jetzt aus dem Cog selbst (__init__ oder setup)
                    loaded_cogs += 1
                else:
                    # Sollte beim ersten Start nicht passieren
                    print(f'    ❕ Already loaded {extension_name}, skipping.')
            except Exception as e:
                print(f'    ❗️ FAILED to load extension {extension_name}.', file=sys.stderr)
                print(f'      Error Type: {type(e).__name__}', file=sys.stderr)
                print(f'      Error: {e}', file=sys.stderr)
                traceback.print_exc() # Gibt den vollen Traceback aus
                failed_cogs += 1
        # elif os.path.isdir(os.path.join(cogs_path, filename)):
            # Optional: Log, dass Ordner übersprungen werden
            # print(f"  📁 Skipping directory: {filename}")
        # else:
            # Optional: Log, dass andere Dateien übersprungen werden
            # print(f"  ⏩ Skipping file: {filename}")

    print(f"🏁 Cogs loading finished: {loaded_cogs} successful, {failed_cogs} failed.")
    print(f"--- Currently loaded extensions: {list(bot.extensions.keys())} ---") # Zeigt geladene Cogs

# --- Haupt Ausführungsfunktion ---
async def main():
    # Datenbank initialisieren (Tabellen erstellen/prüfen)
    try:
        db.setup_database()
    except Exception as e:
        print(f"❌ FATAL ERROR during database setup: {e}", file=sys.stderr)
        traceback.print_exc()
        sys.exit("Database setup failed. Exiting.")

    # Cogs laden
    async with bot: # Context Manager stellt sicher, dass Ressourcen aufgeräumt werden
        await load_extensions()
        # Bot starten
        print("🚀 Starting Bot...")
        try:
            await bot.start(TOKEN)
        except discord.LoginFailure:
            print("❌ FATAL ERROR: Improper token passed.", file=sys.stderr)
            print("   Please ensure your bot token in the .env file is correct and valid.", file=sys.stderr)
        except discord.PrivilegedIntentsRequired:
            print("❌ FATAL ERROR: Privileged Intents (Members/Presence) are not enabled for your bot.", file=sys.stderr)
            print("   Please enable them in the Discord Developer Portal: https://discord.com/developers/applications", file=sys.stderr)
        except Exception as e:
            print(f"❌ An unexpected error occurred during bot runtime:", file=sys.stderr)
            print(f"  Error Type: {type(e).__name__}", file=sys.stderr)
            print(f"  Error: {e}", file=sys.stderr)
            traceback.print_exc()
        finally:
            # Wird normalerweise nicht erreicht, wenn der Bot läuft, außer bei Fehlern
            if not bot.is_closed():
                print("🔌 Closing bot connection unexpectedly...")
                await bot.close()

# --- Skriptstart ---
if __name__ == "__main__":
    try:
        print("Initializing bot...")
        # Stellt sicher, dass asyncio richtig unter Windows läuft
        if sys.platform == "win32":
             asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Bot shutdown initiated by user (Ctrl+C).")
    except Exception as global_error:
        # Fängt alle anderen unerwarteten Fehler beim Start ab
        print(f"\n💥 A critical error occurred outside the main bot loop:", file=sys.stderr)
        print(f"  Error Type: {type(global_error).__name__}", file=sys.stderr)
        print(f"  Error: {global_error}", file=sys.stderr)
        traceback.print_exc()
    finally:
        print("Bot script finished.")